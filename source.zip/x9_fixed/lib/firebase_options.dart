// File generated from google-services.json
// ignore_for_file: lines_longer_than_80_chars, avoid_classes_with_only_static_members
import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart'
    show defaultTargetPlatform, kIsWeb, TargetPlatform;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) return android; // fallback
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      case TargetPlatform.iOS:
        return android; // no iOS client in json, reuse
      default:
        return android;
    }
  }

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyAt3fcQ0BcEEcrgoEmxX0Bt4u2e-V9Ye0E',
    appId: '1:352936738753:android:33f312387c7785ba25f940',
    messagingSenderId: '352936738753',
    projectId: 'hayu-c4eb3',
    storageBucket: 'hayu-c4eb3.firebasestorage.app',
  );
}
